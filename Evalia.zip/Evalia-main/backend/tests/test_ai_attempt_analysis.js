require("dotenv").config({ path: __dirname + "/../.env" });
const assert = require("assert");
const AIService = require("../services/aiService");
const AssignmentModel = require("../models/AssignmentModel");

async function runAIAttemptAnalysisTest() {
  console.log("🧪 Testing AI Student Attempt Performance Analysis...");

  const mockAttempt = {
    earnedScore: 85,
    totalPoints: 100,
    percentage: 85,
    timeSpentSeconds: 1200,
    proctoringFlags: 0,
  };

  const mockQuestionsBreakdown = [
    {
      questionId: "q1",
      prompt: "What is the primary function of an Amazon EC2 instance?",
      type: "MCQ",
      points: 20,
      earned: 20,
      studentAnswer: "Virtual server hosting",
      correctAnswer: "Virtual server hosting",
      isCorrect: true,
    },
    {
      questionId: "q2",
      prompt: "Explain the purpose of Docker containers in cloud deployment.",
      type: "short_answer",
      points: 20,
      earned: 20,
      studentAnswer: "Encapsulates application code and dependencies",
      correctAnswer: "Encapsulates application code and dependencies",
      isCorrect: true,
    },
    {
      questionId: "q3",
      prompt: "Write a recursive algorithm for binary search tree traversal.",
      type: "coding",
      points: 30,
      earned: 15,
      studentAnswer: "def traverse(node): return traverse(node.left)",
      correctAnswer: "def traverse(node): if node: traverse(node.left); print(node.val); traverse(node.right)",
      isCorrect: false,
    },
    {
      questionId: "q4",
      prompt: "In Kubernetes, a [Pod] is the smallest deployable unit.",
      type: "fill_in_blank",
      points: 30,
      earned: 30,
      studentAnswer: "Pod",
      correctAnswer: "Pod",
      isCorrect: true,
    },
  ];

  console.log("1️⃣ Calling AIService.analyzeAttemptPerformance...");
  const analysis = await AIService.analyzeAttemptPerformance({
    attempt: mockAttempt,
    questionsBreakdown: mockQuestionsBreakdown,
    studentName: "Alex Rivera",
    assignmentTitle: "Cloud Computing Midterm",
    courseName: "CS 401",
  });

  assert(analysis, "Analysis object must exist");
  assert(analysis.overallRating, "overallRating must be populated");
  assert(analysis.executiveSummary, "executiveSummary must be populated");
  assert.equal(typeof analysis.scorePercentage, "number");
  assert(Array.isArray(analysis.conceptMastery), "conceptMastery must be an array");
  assert(analysis.conceptMastery.length > 0, "conceptMastery must have at least 1 topic");
  assert(Array.isArray(analysis.strengths), "strengths must be an array");
  assert(Array.isArray(analysis.weaknesses), "weaknesses must be an array");
  assert(Array.isArray(analysis.questionFeedback), "questionFeedback must be an array");
  assert.equal(analysis.questionFeedback.length, 4, "Must have feedback for all 4 questions");
  assert(analysis.studyPlan, "studyPlan must exist");
  assert(analysis.pacingAndConduct, "pacingAndConduct must exist");

  console.log("✅ Analysis Output Verified:");
  console.log(`   - Overall Rating: ${analysis.overallRating}`);
  console.log(`   - Executive Summary: ${analysis.executiveSummary.slice(0, 100)}...`);
  console.log(`   - Concept Mastery Items: ${analysis.conceptMastery.length}`);
  console.log(`   - Strengths Count: ${analysis.strengths.length}`);
  console.log(`   - Weaknesses Count: ${analysis.weaknesses.length}`);
  console.log(`   - Recommended Study Hours: ${analysis.studyPlan.recommendedHours}`);
  console.log(`   - Pacing Verdict: ${analysis.pacingAndConduct.pacingVerdict}`);

  console.log("\n2️⃣ Testing In-Memory & Database Cache Protocol...");
  const testAttemptId = "test-attempt-ai-" + Date.now();
  await AssignmentModel.saveAttemptAIAnalysis(testAttemptId, analysis);

  const cached = await AssignmentModel.getAttemptAIAnalysis(testAttemptId);
  assert(cached, "Cached analysis must be retrievable");
  assert.equal(cached.overallRating, analysis.overallRating, "Cached rating must match");
  console.log("✅ Cache Retrieval Verified!");

  console.log("\n🎉 ALL AI ATTEMPT PERFORMANCE ANALYSIS TESTS PASSED SUCCESSFULLY!\n");
}

runAIAttemptAnalysisTest().catch((err) => {
  console.error("❌ Test Failed:", err);
  process.exit(1);
});
