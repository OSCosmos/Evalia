const assert = require("assert");
const MultiSourceResourceScraper = require("../services/multiSourceResourceScraper");
const { LearningResourcePool } = require("../services/learningResourcePool");
const AIService = require("../services/aiService");

async function runTests() {
  console.log("=== Testing MultiSourceResourceScraper & Revision Pack ===");

  // 1. Test Scraper with "Database Normalization" and "Needs Review"
  console.log("1. Testing scrapeVariableSourcesForTopic for Database Normalization (Needs Review)...");
  const normPack = await MultiSourceResourceScraper.scrapeVariableSourcesForTopic("Database Normalization", "Needs Review");
  assert(normPack, "Expected scraped pack to be returned");
  assert.strictEqual(normPack.topic, "Database Normalization");
  assert.strictEqual(normPack.performanceLevel, "Needs Review");
  assert(normPack.videoTutorials.length > 0, "Expected video tutorials");
  assert(normPack.interactiveSandboxes.length > 0, "Expected interactive sandboxes");
  assert(normPack.documentationAndArticles.length > 0, "Expected documentation & articles");
  assert(normPack.cheatSheetsAndRules.length > 0, "Expected cheatsheets");
  assert(normPack.focusStrategy, "Expected focus strategy");
  console.log("   Video Tutorials count:", normPack.videoTutorials.length);
  console.log("   Interactive Sandboxes count:", normPack.interactiveSandboxes.length);
  console.log("   Documentation count:", normPack.documentationAndArticles.length);
  console.log("   Cheatsheet rules count:", normPack.cheatSheetsAndRules.length);
  if (normPack.liveAcademicContext) {
    console.log("   Live Wikipedia Summary:", normPack.liveAcademicContext.title, "->", normPack.liveAcademicContext.extract.slice(0, 80) + "...");
  }
  console.log("   Passed test 1!");

  // 2. Test Scraper adaptation for "SQL Joins" with "Strong"
  console.log("2. Testing scraper adaptation for SQL Joins (Strong)...");
  const joinPack = await MultiSourceResourceScraper.scrapeVariableSourcesForTopic("SQL Joins", "Strong");
  assert(joinPack, "Expected joinPack");
  assert.strictEqual(joinPack.performanceLevel, "Strong");
  assert(joinPack.focusStrategy.tier.includes("Advanced") || joinPack.focusStrategy.tier.includes("Architecture"), "Expected advanced tier for Strong");
  console.log("   Focus tier:", joinPack.focusStrategy.tier);
  console.log("   Passed test 2!");

  // 3. Test LearningResourcePool self check questions
  console.log("3. Testing LearningResourcePool self-check questions...");
  const normQuestions = LearningResourcePool.getSelfCheckQuestions("Database Normalization");
  assert(Array.isArray(normQuestions) && normQuestions.length >= 2, "Expected at least 2 questions");
  assert(normQuestions[0].options.length >= 3, "Expected multiple options");
  assert(typeof normQuestions[0].correctIndex === "number", "Expected correct index");
  console.log("   Self-check questions count:", normQuestions.length);
  console.log("   Sample question prompt:", normQuestions[0].prompt.slice(0, 60) + "...");
  console.log("   Passed test 3!");

  // 4. Test AIService.generateAssessmentReview
  console.log("4. Testing AIService.generateAssessmentReview...");
  const mockAttempt = {
    attemptId: "test-attempt-1",
    assignmentTitle: "Relational Databases & SQL Exam",
    studentName: "Alex Mercer",
    score: 68,
    questionsBreakdown: [
      {
        questionId: "q1",
        prompt: "Decompose this table into Third Normal Form (3NF) eliminating transitive dependencies.",
        topicTitle: "Database Normalization",
        isCorrect: false,
        difficulty: "Hard",
        earned: 0,
        points: 10,
      },
      {
        questionId: "q2",
        prompt: "Write a SQL query using LEFT JOIN to retain non-matching department records.",
        topicTitle: "SQL Joins",
        isCorrect: true,
        difficulty: "Medium",
        earned: 7,
        points: 10,
      },
      {
        questionId: "q3",
        prompt: "Design an Entity-Relationship model with crow's foot notation.",
        topicTitle: "Entity-Relationship Modeling",
        isCorrect: true,
        difficulty: "Medium",
        earned: 10,
        points: 10,
      },
    ],
  };

  const review = await AIService.generateAssessmentReview(mockAttempt);
  assert(review, "Expected review to be generated");
  assert.strictEqual(review.title, "Review My Assessment");
  assert.strictEqual(review.summary, "You have completed this assessment.");
  assert(review.subheading.includes("areas that could use further revision"));
  assert(review.areas.length >= 3, "Expected at least 3 review areas");
  console.log("   Review summary:", review.summary);
  console.log("   Review subheading:", review.subheading);
  review.areas.forEach((area, i) => {
    console.log(`   ${i + 1}. ${area.topic} | Performance: ${area.performance} (Accuracy: ${area.accuracyPercentage}%)`);
  });
  // Check order: Needs Review should be first
  assert.strictEqual(review.areas[0].performance, "Needs Review");
  console.log("   Passed test 4!");

  // 5. Test AIService.generateRevisionPack
  console.log("5. Testing AIService.generateRevisionPack...");
  const revisionPack = await AIService.generateRevisionPack({
    attemptId: mockAttempt.attemptId,
    assignmentTitle: mockAttempt.assignmentTitle,
    studentName: mockAttempt.studentName,
    overallScore: mockAttempt.score,
    areas: review.areas,
  });

  assert(revisionPack, "Expected revisionPack");
  assert.strictEqual(revisionPack.packTitle, "Your Personalized Revision Pack");
  assert.strictEqual(revisionPack.modules.length, review.areas.length);
  console.log("   Pack Title:", revisionPack.packTitle);
  console.log("   Modules count:", revisionPack.totalModules);
  console.log("   Total recommended hours:", revisionPack.recommendedTotalHours);
  revisionPack.modules.forEach((mod) => {
    console.log(`   Module [${mod.topic}] -> Level: ${mod.performance}, Videos: ${mod.videoTutorials.length}, Sandboxes: ${mod.interactiveSandboxes.length}, Docs: ${mod.documentationAndArticles.length}, Self-Check Quizzes: ${mod.selfCheckQuestions.length}`);
    assert(mod.videoTutorials.length > 0);
    assert(mod.interactiveSandboxes.length > 0);
    assert(mod.documentationAndArticles.length > 0);
    assert(mod.cheatSheetsAndRules.length > 0);
    assert(mod.selfCheckQuestions.length > 0);
  });
  console.log("   Passed test 5!");

  console.log("\nALL MULTI-SOURCE REVISION PACK TESTS PASSED SUCCESSFULLY! 🚀");
}

runTests().catch((err) => {
  console.error("Test failure:", err);
  process.exit(1);
});
