"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowLeft,
  Award,
  CheckCircle2,
  Clock,
  Shield,
  ShieldCheck,
  Trophy,
  XCircle,
  FileText,
  Code,
  BookOpen,
  Loader2,
  Sparkles,
  Brain,
  Lightbulb,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Zap,
  Target,
  GraduationCap,
  ArrowRight,
  AlertTriangle,
  Play,
  ExternalLink,
  Layers,
  Video,
  Terminal,
  Check,
  BookmarkCheck,
  Search,
  X,
  Eye,
  Filter,
  Copy,
  Globe,
} from "lucide-react";

function getYouTubeEmbedUrl(url: string): string | null {
  if (!url) return null;
  const regExp =
    /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  const match = url.match(regExp);
  return match && match[1]
    ? `https://www.youtube-nocookie.com/embed/${match[1]}?autoplay=1&rel=0`
    : null;
}

interface ArticleSection {
  heading: string;
  paragraphs: string[];
  codeSnippet?: {
    title: string;
    language: string;
    code: string;
  };
  callout?: string;
}

interface ComprehensiveArticle {
  domain: string;
  abstract: string;
  sections: ArticleSection[];
  assessmentTraps: string[];
  keyRules: string[];
}

function getComprehensiveArticleContent(modal: any): ComprehensiveArticle {
  if (!modal) {
    return {
      domain: "Computer Science",
      abstract: "",
      sections: [],
      assessmentTraps: [],
      keyRules: [],
    };
  }

  const topicStr = (modal.topic || modal.title || "").toLowerCase();
  const extractText = modal.extract || "";
  const existingKeyPoints: string[] = modal.keyPoints || [];

  if (topicStr.includes("normaliz")) {
    return {
      domain: "Database Systems & Relational Theory",
      abstract:
        extractText ||
        "Database Normalization is the mathematical and architectural discipline of structuring relational database schemas to eliminate update, insertion, and deletion anomalies while minimizing redundant data storage. Pioneered by Edgar F. Codd in 1970, normalization systematically decomposes relations based on functional dependencies through First Normal Form (1NF), Second Normal Form (2NF), Third Normal Form (3NF), and Boyce-Codd Normal Form (BCNF).",
      sections: [
        {
          heading: "1. The Relational Anomalies: Why Unnormalized Schemas Fail",
          paragraphs: [
            "In unnormalized databases, data redundancy creates severe operational anomalies during everyday CRUD operations:",
            "• Update Anomaly: If an instructor's office address is recorded in every student enrollment record, changing the instructor's room requires updating hundreds of rows. Inconsistent updates leave the database in an invalid state.",
            "• Insertion Anomaly: If course information and student enrollments are stored in the same table, a new course cannot be recorded until at least one student registers for it, because the student ID is part of the primary key.",
            "• Deletion Anomaly: If the last enrolled student drops a course, deleting that student's record inadvertently purges the entire course definition and instructor record from the database.",
          ],
          callout:
            "Normalization guarantees lossless decomposition: splitting relations ensures no information is lost when executing relational joins.",
        },
        {
          heading: "2. The Progressive Normal Forms (1NF through BCNF)",
          paragraphs: [
            "First Normal Form (1NF): Requires that all attribute domains are atomic (indivisible) and that each row is uniquely identifiable via a primary key. Repeating groups or comma-separated lists in a single field violate 1NF.",
            "Second Normal Form (2NF): Requires the relation to be in 1NF, and additionally that every non-prime attribute is fully functionally dependent on the entire primary key. If a table has a composite primary key (e.g., {student_id, course_id}), any attribute depending on only one part of the key violates 2NF.",
            "Third Normal Form (3NF): Requires 2NF, plus the strict elimination of transitive functional dependencies (X → Y and Y → Z where Z is non-prime). Every non-key column must depend directly on the primary key, rather than via an intermediary column.",
            "Boyce-Codd Normal Form (BCNF): A stricter variant of 3NF where for every non-trivial functional dependency X → Y, the determinant X must be a candidate key (superkey).",
          ],
        },
        {
          heading: "3. Practical Schema Transformation: 0NF to 3NF",
          paragraphs: [
            "Below is a canonical example of taking an unnormalized, anomaly-prone relation and decomposing it into clean, relational 3NF tables with foreign key constraints:",
          ],
          codeSnippet: {
            title: "3NF Relational Decomposition Schema (PostgreSQL/MySQL)",
            language: "sql",
            code: `-- UNNORMALIZED ANOMALOUS SCHEMA:
-- StudentEnrollment(student_id, student_name, course_id, course_title, instructor_id, instructor_name, office_loc)

-- 3NF DECOMPOSED RELATIONS:
CREATE TABLE students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL
);

CREATE TABLE instructors (
    instructor_id INT PRIMARY KEY,
    instructor_name VARCHAR(100) NOT NULL,
    office_location VARCHAR(50)
);

CREATE TABLE courses (
    course_id VARCHAR(10) PRIMARY KEY,
    course_title VARCHAR(100) NOT NULL,
    instructor_id INT REFERENCES instructors(instructor_id)
);

CREATE TABLE enrollments (
    student_id INT REFERENCES students(student_id),
    course_id VARCHAR(10) REFERENCES courses(course_id),
    enrollment_date DATE DEFAULT CURRENT_DATE,
    grade VARCHAR(2),
    PRIMARY KEY (student_id, course_id)
);`,
          },
          callout:
            "Design Guideline: In transactional OLTP systems, normalize to 3NF/BCNF. In analytical OLAP data warehouses, denormalization (Star/Snowflake schema) is intentionally utilized to reduce join latency.",
        },
      ],
      assessmentTraps: [
        "Trap 1: Forgetting that 2NF only applies when the primary key is composite! If a relation has a single-attribute primary key, any 1NF table is automatically in 2NF.",
        "Trap 2: Overlooking transitive dependencies. When column B depends on column A, and column C depends on column B (A → B → C), keeping C in table A violates 3NF.",
        "Trap 3: Lossy decomposition. When decomposing a relation into two sub-relations, the common attribute must be a candidate key in at least one sub-relation to guarantee a lossless join.",
      ],
      keyRules: [
        "1NF: Atomic values only; no repeating arrays or composite values.",
        "2NF: No partial dependency on a composite primary key.",
        "3NF: No transitive dependency on non-prime attributes.",
        "BCNF: In every functional dependency X → Y, X must be a superkey.",
        "Mnemonic: Non-key attributes must depend on the key, the whole key, and nothing but the key, so help me Codd.",
      ],
    };
  }

  if (topicStr.includes("join")) {
    return {
      domain: "Database Systems & Relational Algebra",
      abstract:
        extractText ||
        "SQL Joins are relational algebraic operators that combine tuples from two or more relations based on a common matching predicate. Efficient joins form the operational backbone of relational database query execution and indexing architecture.",
      sections: [
        {
          heading: "1. Relational Algebra of Joins",
          paragraphs: [
            "Conceptually, any SQL Join begins with the Cartesian Product (R × S) of two tables, producing every possible pair of tuples. The join condition (theta-predicate) then filters this product down to matching rows.",
            "• INNER JOIN: Computes the intersection. Discards unmatched rows from both tables; only rows satisfying the predicate are returned.",
            "• LEFT OUTER JOIN: Preserves every row from the left table. When no corresponding row exists in the right table, right-side columns are filled with NULL values.",
            "• RIGHT OUTER JOIN: Symmetric to LEFT JOIN; preserves all right-table rows.",
            "• FULL OUTER JOIN: Retains unmatched rows from both tables, filling missing attributes on either side with NULL.",
            "• CROSS JOIN: Evaluates the unconstrained Cartesian product, returning M × N total rows.",
          ],
        },
        {
          heading: "2. The Critical Difference: ON vs. WHERE in Outer Joins",
          paragraphs: [
            "The ON clause dictates which rows from the right table are matched to the left table during the join operation. The WHERE clause, by contrast, filters the combined result set after the join has completed.",
            "Placing a right-table filtering condition in the WHERE clause instead of the ON clause will discard NULL-padded rows, unintentionally converting a LEFT JOIN into an INNER JOIN!",
          ],
          codeSnippet: {
            title: "Accidental Inner Join Bug vs. Correct Outer Join Predicate",
            language: "sql",
            code: `-- ❌ BUGGY QUERY (Accidental conversion to INNER JOIN):
-- Filtering s.status in WHERE discards candidates with no submissions (s.status IS NULL)
SELECT 
    c.candidate_id,
    c.full_name,
    s.submission_id,
    s.score
FROM candidates c
LEFT JOIN submissions s ON c.candidate_id = s.candidate_id
WHERE s.status = 'GRADED'; -- Discards unmatched left rows!

-- ✅ CORRECT QUERY (Preserves all candidates):
-- Filtering s.status inside the ON clause preserves candidates without submissions
SELECT 
    c.candidate_id,
    c.full_name,
    s.submission_id,
    s.score
FROM candidates c
LEFT JOIN submissions s 
    ON c.candidate_id = s.candidate_id 
    AND s.status = 'GRADED';`,
          },
          callout:
            "Golden Rule: If unmatched left-hand rows must remain in the final result, all conditions restricting the right-hand table MUST be placed inside the ON clause.",
        },
        {
          heading: "3. Physical Join Algorithms Under the Hood",
          paragraphs: [
            "Database query optimizers (PostgreSQL, MySQL, Oracle) choose between three primary execution strategies based on table statistics and available indexes:",
            "1. Nested Loop Join: Scans the outer table and probes an index on the inner table for each row. Ideal for small datasets ($O(M \\times \\log N)$).",
            "2. Hash Join: Builds an in-memory hash table on the join key of the smaller relation, then streams the larger relation through the hash table ($O(M + N)$).",
            "3. Sort-Merge Join: Sorts both relations by the join key and scans through them in parallel lockstep. Preferred when inputs are already pre-sorted by clustered indexes.",
          ],
        },
      ],
      assessmentTraps: [
        "Trap 1: The 'Accidental Inner Join' caused by filtering the right table in the WHERE clause instead of the ON clause.",
        "Trap 2: Cartesian explosions caused by missing join conditions or joining on non-unique keys without aggregation.",
        "Trap 3: Counting with COUNT(*) vs COUNT(column). In a LEFT JOIN, COUNT(*) counts the NULL-padded row as 1, while COUNT(right_table.id) correctly returns 0 for unmatched entities.",
      ],
      keyRules: [
        "Join matching conditions belong in ON; post-join output filters belong in WHERE.",
        "Always index foreign keys used in join predicates to enable Hash and Index scans.",
        "Use COUNT(table.id) rather than COUNT(*) when aggregating over outer joins.",
        "In a 1:N join, rows on the 'One' side will be duplicated for every matching 'Many' row.",
      ],
    };
  }

  if (topicStr.includes("entity") || topicStr.includes("erd") || topicStr.includes("relat")) {
    return {
      domain: "Conceptual Database Modeling & Information Architecture",
      abstract:
        extractText ||
        "Entity-Relationship (ER) Modeling, introduced by Peter Chen in 1976, is a high-level conceptual data modeling methodology that represents real-world domains through entity sets, relationship sets, attributes, and structural constraints before physical schema implementation.",
      sections: [
        {
          heading: "1. Core Primitives of ER Diagrams",
          paragraphs: [
            "• Entities: Real-world physical or conceptual objects (e.g., Student, Course, Invoice). Strong entities have independent primary keys; Weak entities depend on an identifying relationship with an owner entity for identification.",
            "• Attributes: Properties of entities. Simple (atomic), Composite (name divided into first/last), Multivalued (skills or phone numbers; drawn with double ovals), and Derived (age calculated from birthdate; drawn with dashed ovals).",
            "• Relationships: Associations among entity sets. Expressed via degree (Unary, Binary, Ternary) and cardinality constraints.",
          ],
        },
        {
          heading: "2. Cardinality Ratios & Participation Constraints",
          paragraphs: [
            "Cardinality ratios define numerical bounds on entity participation:",
            "• One-to-One (1:1): The foreign key should be placed on the side with total participation to avoid NULL entries.",
            "• One-to-Many (1:N): The foreign key is ALWAYS placed in the table on the 'Many' side referencing the primary key of the 'One' side.",
            "• Many-to-Many (M:N): Cannot be directly modeled in relational tables without creating an associative (junction) bridge table.",
            "• Participation Constraints: Total participation (double line) requires every entity instance to be involved in the relationship; Partial participation allows instances to exist independently.",
          ],
        },
        {
          heading: "3. Mapping ER Diagrams to Physical Relational Schemas",
          paragraphs: [
            "Converting conceptual ER models to relational DDL requires algorithmic precision, especially for Many-to-Many relationships:",
          ],
          codeSnippet: {
            title: "Physical Schema Mapping for an M:N Relationship with Composite PK",
            language: "sql",
            code: `-- Conceptual Model: Doctor (M) <--- treats ---> (N) Patient
-- M:N Decomposition requires an associative junction table:

CREATE TABLE doctors (
    doctor_id SERIAL PRIMARY KEY,
    license_number VARCHAR(50) UNIQUE NOT NULL,
    specialty VARCHAR(100) NOT NULL
);

CREATE TABLE patients (
    patient_id SERIAL PRIMARY KEY,
    mrn VARCHAR(50) UNIQUE NOT NULL,
    date_of_birth DATE NOT NULL
);

-- Junction Table with Composite Primary Key:
CREATE TABLE doctor_patient_appointments (
    doctor_id INT NOT NULL REFERENCES doctors(doctor_id) ON DELETE CASCADE,
    patient_id INT NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    appointment_time TIMESTAMP NOT NULL,
    diagnosis_notes TEXT,
    PRIMARY KEY (doctor_id, patient_id, appointment_time)
);`,
          },
          callout:
            "Schema Anti-pattern: Never store foreign keys as a comma-separated string or array in an entity row. This destroys relational indexing and violates First Normal Form.",
        },
      ],
      assessmentTraps: [
        "Trap 1: Placing the Foreign Key on the 'One' side of a 1:N relationship instead of the 'Many' side.",
        "Trap 2: Forgetting that a Weak Entity's primary key is composite: it consists of the owner entity's primary key plus its own partial discriminator.",
        "Trap 3: Omitting the junction table for M:N relationships, attempting to create circular foreign keys.",
      ],
      keyRules: [
        "1:N Foreign keys ALWAYS live on the 'Many' child table.",
        "M:N relationships ALWAYS require an associative junction table.",
        "Weak entities require an identifying relationship and composite PK with owner.",
      ],
    };
  }

  if (topicStr.includes("cloud")) {
    return {
      domain: "Distributed Systems & Cloud Architecture",
      abstract:
        extractText ||
        "Cloud Architecture is the discipline of orchestrating virtualized compute, storage, networking, and managed services to create highly available, horizontally scalable, and resilient distributed applications. Key pillars include stateless compute design, asynchronous messaging, multi-AZ deployment, and the Cloud Shared Responsibility Model.",
      sections: [
        {
          heading: "1. Core Distributed Systems Tenets",
          paragraphs: [
            "• Horizontal Scalability (Scale-Out): Instead of provisioning larger virtual machines (Scale-Up), cloud architectures add identical stateless worker instances behind Elastic Load Balancers (ELBs) based on dynamic traffic metrics.",
            "• Decoupling via Asynchronous Messaging: Microservices communicate via message queues (SQS, Kafka) and publish/subscribe topics (SNS). If a consumer service experiences latency or crashes, messages accumulate safely in the queue rather than failing client requests.",
            "• Resilience Across Availability Zones (AZs): High availability requires deploying instances across at least two physically isolated Availability Zones within a region to withstand power or hardware outages.",
          ],
        },
        {
          heading: "2. The Cloud Shared Responsibility Model",
          paragraphs: [
            "• Security OF the Cloud: The cloud provider manages the physical infrastructure, data center facilities, hardware hypervisors, and core networking backbones.",
            "• Security IN the Cloud: The customer is responsible for operating system patching, IAM access control policies, data encryption at rest and in transit, and database backups.",
          ],
        },
        {
          heading: "3. Stateless Application Architecture Implementation",
          paragraphs: [
            "Never store session state on local server disks. Centralizing session data in a distributed cache allows any backend instance to serve incoming requests:",
          ],
          codeSnippet: {
            title: "Stateless Session Management via Distributed Cache (TypeScript)",
            language: "typescript",
            code: `import Redis from "ioredis";
const sessionStore = new Redis(process.env.REDIS_CLUSTER_URL);

// Middleware: Distributed Stateless Authentication
export async function authenticateSession(req: any, res: any, next: any) {
  const sessionId = req.headers["x-session-token"];
  if (!sessionId) return res.status(401).json({ error: "Missing token" });

  // Centralized session lookup allows ANY autoscaled worker instance to handle the request:
  const sessionData = await sessionStore.get(\`session:\${sessionId}\`);
  if (!sessionData) return res.status(401).json({ error: "Session expired" });

  req.user = JSON.parse(sessionData);
  next();
}`,
          },
          callout:
            "Cloud Axiom: Treat compute instances as cattle, not pets. Any individual server can be terminated at any moment by auto-scalers without data loss.",
        },
      ],
      assessmentTraps: [
        "Trap 1: Believing the cloud provider automatically backs up and encrypts application data by default.",
        "Trap 2: Storing user upload files directly on local server disks (EBS) instead of scalable object storage (S3) behind a CDN.",
        "Trap 3: Designing synchronous HTTP chains between microservices instead of event-driven asynchronous queues.",
      ],
      keyRules: [
        "Keep compute tiers 100% stateless; offload state to distributed caches and managed databases.",
        "Deploy applications across multiple Availability Zones (Multi-AZ).",
        "Customer owns Security IN the cloud; Provider owns Security OF the cloud.",
      ],
    };
  }

  if (topicStr.includes("pattern") || topicStr.includes("solid")) {
    return {
      domain: "Software Architecture & Object-Oriented Design",
      abstract:
        extractText ||
        "Software Design Patterns represent formalized, battle-tested solutions to recurring design problems in software engineering. Categorized by the Gang of Four (GoF) into Creational, Structural, and Behavioral patterns, these abstractions promote loose coupling, high cohesion, and adherence to the SOLID principles.",
      sections: [
        {
          heading: "1. The SOLID Foundation",
          paragraphs: [
            "• Single Responsibility Principle (SRP): A class should have one, and only one, reason to change.",
            "• Open/Closed Principle (OCP): Software entities should be open for extension, but closed for modification.",
            "• Liskov Substitution Principle (LSP): Subtypes must be substitutable for their base types without altering program correctness.",
            "• Interface Segregation Principle (ISP): Clients should not be forced to depend upon interfaces they do not use.",
            "• Dependency Inversion Principle (DIP): High-level modules should depend on abstractions, not on concrete low-level details.",
          ],
        },
        {
          heading: "2. The Gang of Four (GoF) Taxonomy",
          paragraphs: [
            "• Creational Patterns: Deal with object creation mechanisms (Factory Method, Abstract Factory, Singleton, Builder).",
            "• Structural Patterns: Deal with object composition and class interfaces (Adapter, Decorator, Facade, Composite, Proxy).",
            "• Behavioral Patterns: Deal with algorithms and the assignment of responsibilities between objects (Strategy, Observer, Command, State).",
          ],
        },
        {
          heading: "3. Clean Architecture Implementation: The Strategy Pattern",
          paragraphs: [
            "Eliminate nested conditional switch statements by encapsulating algorithms into interchangeable strategy classes:",
          ],
          codeSnippet: {
            title: "Strategy Pattern Implementation (TypeScript)",
            language: "typescript",
            code: `// Strategy Interface (DIP)
interface PaymentStrategy {
  processPayment(amount: number): Promise<boolean>;
}

class StripePaymentStrategy implements PaymentStrategy {
  async processPayment(amount: number): Promise<boolean> {
    console.log(\`Charging \$\${amount} via Stripe API...\`);
    return true;
  }
}

class PayPalPaymentStrategy implements PaymentStrategy {
  async processPayment(amount: number): Promise<boolean> {
    console.log(\`Redirecting to PayPal for \$\${amount}...\`);
    return true;
  }
}

// Client Context depends only on the abstraction
class CheckoutService {
  constructor(private paymentStrategy: PaymentStrategy) {}

  public setStrategy(strategy: PaymentStrategy) {
    this.paymentStrategy = strategy;
  }

  public async executeCheckout(total: number) {
    return this.paymentStrategy.processPayment(total);
  }
}`,
          },
          callout:
            "Design Axiom: Favor composition over inheritance. Deep inheritance hierarchies create fragile, tightly-coupled codebases that resist change.",
        },
      ],
      assessmentTraps: [
        "Trap 1: Overuse of the Singleton pattern, turning it into a global state anti-pattern that inhibits unit testing.",
        "Trap 2: Deep conditional branching (nested if/switch) that violates the Open/Closed Principle.",
        "Trap 3: Violating Liskov Substitution by throwing 'NotSupportedException' in subclass methods.",
      ],
      keyRules: [
        "Favor object composition over class inheritance.",
        "Program to an interface, not an implementation.",
        "Single Responsibility: Every module should have one, and only one, reason to change.",
      ],
    };
  }

  // Dynamic Fallback Generator for any general topic
  const keyPointsList =
    existingKeyPoints.length > 0
      ? existingKeyPoints
      : [
          `Verify foundational definitions and formal constraints for ${modal.title || modal.topic}.`,
          `Analyze memory and computational complexity trade-offs before implementation.`,
          `Avoid common edge case pitfalls during assessment evaluations.`,
        ];

  return {
    domain: modal.source || "Academic Computer Science",
    abstract:
      extractText ||
      `Comprehensive academic guide and technical analysis for ${modal.title || modal.topic}. This curriculum review synthesizes authoritative university lecture principles, operational mechanics, syntax rules, and assessment remediation points to ensure mastery.`,
    sections: [
      {
        heading: "1. Foundational Theory & Conceptual Overview",
        paragraphs: [
          extractText ||
            `${modal.title || modal.topic} represents a foundational concept in computing. Understanding both the theoretical mathematical properties and practical implementation trade-offs is essential for high-performance software engineering and technical assessments.`,
          `When analyzing this topic, practitioners must balance structural correctness, maintainability, and operational complexity. Formal definitions establish unambiguous boundaries that prevent edge-case failures.`,
        ],
      },
      {
        heading: "2. Operational Mechanics & Technical Principles",
        paragraphs: [
          `Key operational rules and syntax requirements for ${modal.topic || modal.title}:`,
          ...keyPointsList.map((pt) => `• ${pt}`),
        ],
        callout:
          `Study Strategy: When revising ${modal.topic || modal.title}, focus on verifying boundary conditions and structural edge cases before your next assessment attempt.`,
      },
      {
        heading: "3. Best Practices & Remediation Takeaways",
        paragraphs: [
          `During assessment drills, candidates frequently encounter questions targeting subtle edge conditions. Ensure you can identify both standard happy-path behavior and non-standard input handling.`,
          `Practice applying these concepts in isolation before combining them into full-scale system designs.`,
        ],
      },
    ],
    assessmentTraps: [
      `Failing to verify input constraints and boundary conditions.`,
      `Overlooking time and space complexity scaling characteristics.`,
      `Conflating theoretical abstraction with implementation-specific side effects.`,
    ],
    keyRules: keyPointsList,
  };
}

export default function ResultStatus() {
  const params = useParams();
  const attemptId = params?.attemptId as string;

  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<any>(null);

  // AI Performance Analysis State
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [generatingAI, setGeneratingAI] = useState(false);
  const [generationStep, setGenerationStep] = useState("");
  const [aiError, setAiError] = useState<string | null>(null);
  const [expandedQuestions, setExpandedQuestions] = useState<
    Record<string, boolean>
  >({});
  const hasAutoTriggered = useRef(false);

  // Assessment Review & Revision Pack State
  const [assessmentReview, setAssessmentReview] = useState<any>(null);
  const [loadingReview, setLoadingReview] = useState(false);
  const [revisionPack, setRevisionPack] = useState<any>(null);
  const [generatingPack, setGeneratingPack] = useState(false);
  const [packStep, setPackStep] = useState("");
  const [packError, setPackError] = useState<string | null>(null);
  const [activeModuleTab, setActiveModuleTab] = useState(0);

  // Revision Pack Filtering & In-System Consumption (Watch & Read)
  const [resourceSearchQuery, setResourceSearchQuery] = useState("");
  const [resourceTypeFilter, setResourceTypeFilter] = useState<
    "all" | "video" | "doc" | "cheatsheet"
  >("all");
  const [searchScope, setSearchScope] = useState<"current" | "all">("current");

  // In-System Video Player Modal State ("On Watch")
  const [activeVideoModal, setActiveVideoModal] = useState<{
    title: string;
    platform: string;
    url: string;
    duration?: string;
    level?: string;
    topic?: string;
  } | null>(null);
  const [watchedVideos, setWatchedVideos] = useState<Record<string, boolean>>({});

  // In-System Document Reader Modal State ("On Read")
  const [activeDocModal, setActiveDocModal] = useState<{
    title: string;
    source: string;
    url: string;
    difficulty?: string;
    extract?: string;
    keyPoints?: string[];
    topic?: string;
    readingTime?: string;
  } | null>(null);
  const [readDocs, setReadDocs] = useState<Record<string, boolean>>({});
  const [readerFontSize, setReaderFontSize] = useState<number>(15);
  const [readerTab, setReaderTab] = useState<"article" | "webview">("article");
  const [copiedCodeIdx, setCopiedCodeIdx] = useState<number | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setActiveVideoModal(null);
        setActiveDocModal(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // On-Demand Visibility: AI analysis and Revision Pack are hidden by default
  const [showAISection, setShowAISection] = useState(false);
  const [showRevisionSection, setShowRevisionSection] = useState(false);

  useEffect(() => {
    if (!attemptId) return;

    let isMounted = true;
    const fetchResult = async () => {
      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;
      try {
        const res = await fetch(
          `http://localhost:5000/api/v1/assignments/attempts/${attemptId}`,
          {
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
          },
        );
        const data = await res.json();
        if (isMounted && data.success && data.data?.result) {
          const resObj = data.data.result;
          setResult(resObj);
          if (resObj.aiAnalysis) {
            setAiAnalysis(resObj.aiAnalysis);
          }
        }
      } catch (err) {
        console.warn("Could not fetch live attempt result:", err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchResult();
    return () => {
      isMounted = false;
    };
  }, [attemptId]);

  const handleOpenAISection = async () => {
    if (showAISection) {
      setShowAISection(false);
      return;
    }
    setShowAISection(true);
    setTimeout(() => {
      document
        ?.getElementById("ai-performance-section")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 120);
    if (!aiAnalysis && !generatingAI) {
      await handleGenerateAI(false);
    }
  };

  const fetchReviewAreas = async () => {
    if (!attemptId) return;
    try {
      setLoadingReview(true);
      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;
      // 1. Fetch Review Areas
      const reviewRes = await fetch(
        `http://localhost:5000/api/v1/assignments/attempts/${attemptId}/assessment-review`,
        {
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
        },
      );
      const reviewData = await reviewRes.json();
      if (reviewData.success && reviewData.data?.review) {
        setAssessmentReview(reviewData.data.review);
      }

      // 2. Fetch Cached Revision Pack if available
      const packRes = await fetch(
        `http://localhost:5000/api/v1/assignments/attempts/${attemptId}/revision-pack`,
        {
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
        },
      );
      const packData = await packRes.json();
      if (packData.success && packData.data?.revisionPack) {
        setRevisionPack(packData.data.revisionPack);
      }
    } catch (err) {
      console.warn("Could not fetch assessment review / revision pack:", err);
    } finally {
      setLoadingReview(false);
    }
  };

  const handleOpenRevisionSection = async () => {
    if (showRevisionSection) {
      setShowRevisionSection(false);
      return;
    }
    setShowRevisionSection(true);
    setTimeout(() => {
      document
        ?.getElementById("revision-pack-section")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 120);
    if (!assessmentReview && !loadingReview) {
      await fetchReviewAreas();
    }
  };

  const handleGenerateAI = async (regenerate = false) => {
    if (!attemptId) return;
    try {
      setGeneratingAI(true);
      setAiError(null);
      setGenerationStep("Analyzing test responses against rubric criteria...");

      const t1 = setTimeout(() => {
        setGenerationStep(
          "Evaluating conceptual strengths & knowledge gaps...",
        );
      }, 1100);

      const t2 = setTimeout(() => {
        setGenerationStep("Formulating personalized remedial study plan...");
      }, 2300);

      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;
      const res = await fetch(
        `http://localhost:5000/api/v1/assignments/attempts/${attemptId}/ai-analysis`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ regenerate }),
        },
      );

      clearTimeout(t1);
      clearTimeout(t2);

      const data = await res.json();
      if (data.success && data.data?.analysis) {
        setAiAnalysis(data.data.analysis);
      } else {
        throw new Error(data.message || "Unable to generate AI analysis.");
      }
    } catch (err: any) {
      setAiError(err.message || "Failed to generate AI performance analysis.");
    } finally {
      setGeneratingAI(false);
      setGenerationStep("");
    }
  };

  const toggleQuestionExpanded = (qId: string) => {
    setExpandedQuestions((prev) => ({ ...prev, [qId]: !prev[qId] }));
  };

  const handleGenerateRevisionPack = async (regenerate = false) => {
    if (!attemptId) return;
    try {
      setGeneratingPack(true);
      setPackError(null);
      setPackStep(
        "Querying live Wikipedia Academic REST API for concept abstracts...",
      );

      const t1 = setTimeout(() => {
        setPackStep(
          "Aggregating video lectures from MIT OCW and freeCodeCamp...",
        );
      }, 900);

      const t2 = setTimeout(() => {
        setPackStep(
          "Connecting interactive coding sandboxes (SQLBolt, LeetCode, W3Schools)...",
        );
      }, 1900);

      const t3 = setTimeout(() => {
        setPackStep("Curating performance-adapted diagnostic drills & cheatsheets...");
      }, 2900);

      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;

      const res = await fetch(
        `http://localhost:5000/api/v1/assignments/attempts/${attemptId}/revision-pack`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ regenerate }),
        },
      );

      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);

      const data = await res.json();
      if (data.success && data.data?.revisionPack) {
        setRevisionPack(data.data.revisionPack);
        setActiveModuleTab(0);
      } else {
        throw new Error(data.message || "Failed to generate revision pack.");
      }
    } catch (err: any) {
      setPackError(err.message || "Unable to assemble revision pack.");
    } finally {
      setGeneratingPack(false);
      setPackStep("");
    }
  };

  if (loading) {
    return (
      <main
        style={{
          minHeight: "100vh",
          background: "#f7f8fb",
          padding: "60px 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e6e9ef",
            borderRadius: 16,
            padding: "48px 32px",
            textAlign: "center",
            maxWidth: 440,
            width: "100%",
            boxShadow: "0 4px 20px rgba(0,0,0,0.03)",
          }}
        >
          <Loader2
            size={38}
            className="animate-spin"
            style={{ color: "#6255e7", margin: "0 auto 16px" }}
          />
          <h2
            style={{
              fontSize: 18,
              fontWeight: 800,
              color: "#1d2536",
              margin: "0 0 6px",
            }}
          >
            Loading Assessment Results
          </h2>
          <p style={{ fontSize: 13, color: "#64748b", margin: 0 }}>
            Fetching score evaluation, response breakdown &amp; proctoring audit
            log...
          </p>
        </div>
      </main>
    );
  }

  if (!result) {
    return (
      <main
        style={{
          minHeight: "100vh",
          background: "#f7f8fb",
          padding: "32px 24px",
        }}
      >
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div style={{ marginBottom: 20 }}>
            <Link
              href="/user/assignments"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                fontSize: 13,
                fontWeight: 700,
                color: "#6255e7",
                textDecoration: "none",
              }}
            >
              <ArrowLeft size={16} /> Back to My Assignments
            </Link>
          </div>
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e6e9ef",
              borderRadius: 16,
              padding: "48px 32px",
              textAlign: "center",
              boxShadow: "0 4px 20px rgba(0,0,0,0.03)",
            }}
          >
            <XCircle
              size={42}
              style={{ color: "#ef4444", margin: "0 auto 16px" }}
            />
            <h2
              style={{
                fontSize: 18,
                fontWeight: 800,
                color: "#1d2536",
                marginBottom: 6,
              }}
            >
              Attempt Result Not Found
            </h2>
            <p style={{ fontSize: 13, color: "#64748b", margin: 0 }}>
              The requested assessment attempt could not be retrieved from the
              database.
            </p>
          </div>
        </div>
      </main>
    );
  }

  const scorePct = Math.round(
    Number(result.percentage) ||
      (result.totalPoints > 0
        ? (Number(result.earnedScore || 0) / Number(result.totalPoints)) * 100
        : 0),
  );
  const passMark = Number(result.passMark) || 70;
  const isPassed = scorePct >= passMark;
  const flagsCount = Number(result.proctoringFlags) || 0;
  const questionsList = Array.isArray(result.questionsBreakdown)
    ? result.questionsBreakdown
    : [];

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#f7f8fb",
        padding: "32px 24px",
      }}
    >
      <div style={{ maxWidth: 960, margin: "0 auto" }}>
        {/* Top Back Link */}
        <div style={{ marginBottom: 20 }}>
          <Link
            href="/user/assignments"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              fontSize: 13,
              fontWeight: 700,
              color: "#6255e7",
              textDecoration: "none",
            }}
          >
            <ArrowLeft size={16} /> Back to My Assignments
          </Link>
        </div>

        {/* Hero Details Header Card */}
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e6e9ef",
            borderRadius: 16,
            padding: 32,
            boxShadow: "0 4px 20px rgba(0,0,0,0.03)",
            marginBottom: 24,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 20,
              flexWrap: "wrap",
            }}
          >
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  marginBottom: 8,
                }}
              >
                <span
                  style={{
                    fontSize: 12,
                    fontWeight: 800,
                    color: "#6255e7",
                    background: "#f0f3ff",
                    padding: "4px 12px",
                    borderRadius: 6,
                  }}
                >
                  {result.courseCode ? `${result.courseCode} · ` : ""}
                  {result.courseName || "Course Assessment"}
                </span>
                <span
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: isPassed ? "#16a34a" : "#dc2626",
                    background: isPassed ? "#dcfce7" : "#fee2e2",
                    padding: "4px 12px",
                    borderRadius: 6,
                  }}
                >
                  {isPassed ? "Passed ✓" : "Review Required"}
                </span>
              </div>

              <h1
                style={{
                  fontSize: 24,
                  fontWeight: 800,
                  color: "#1d2536",
                  margin: "0 0 8px",
                }}
              >
                {result.assignmentTitle || "Assignment Result"}
              </h1>

              <p
                style={{
                  fontSize: 14,
                  color: "#64748b",
                  margin: 0,
                  lineHeight: 1.5,
                  maxWidth: 640,
                }}
              >
                {result.description ||
                  "Course assessment evaluation and response breakdown."}
              </p>
            </div>

            {/* Score Big Display */}
            <div
              style={{
                background: "#f8fafc",
                border: "1.5px solid #e2e8f0",
                borderRadius: 12,
                padding: "16px 28px",
                textAlign: "center",
                minWidth: 160,
              }}
            >
              <div
                style={{
                  fontSize: 36,
                  fontWeight: 900,
                  color: isPassed ? "#16a34a" : "#2563eb",
                  lineHeight: 1,
                }}
              >
                {scorePct}%
              </div>
              <div
                style={{
                  fontSize: 12,
                  fontWeight: 700,
                  color: "#64748b",
                  marginTop: 6,
                }}
              >
                Score: {result.earnedScore ?? 0} / {result.totalPoints ?? 100}{" "}
                Pts
              </div>
            </div>
          </div>

          {/* Fact Chips */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 16,
              marginTop: 24,
              paddingTop: 20,
              borderTop: "1px solid #f1f5f9",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Clock size={16} color="#64748b" />
              <div>
                <div
                  style={{ fontSize: 11, color: "#64748b", fontWeight: 600 }}
                >
                  Duration Spent
                </div>
                <div
                  style={{ fontSize: 13, fontWeight: 700, color: "#1d2536" }}
                >
                  {Math.round((Number(result.timeSpentSeconds) || 0) / 60)} Mins
                </div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Shield
                size={16}
                color={flagsCount > 0 ? "#ef4444" : "#16a34a"}
              />
              <div>
                <div
                  style={{ fontSize: 11, color: "#64748b", fontWeight: 600 }}
                >
                  Integrity Audit
                </div>
                <div
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: flagsCount > 0 ? "#ef4444" : "#16a34a",
                  }}
                >
                  {flagsCount > 0
                    ? `${flagsCount} Audit Flag(s)`
                    : "✓ Clean Proctoring Session"}
                </div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <BookOpen size={16} color="#64748b" />
              <div>
                <div
                  style={{ fontSize: 11, color: "#64748b", fontWeight: 600 }}
                >
                  Attempt Status
                </div>
                <div
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: "#1d2536",
                    textTransform: "capitalize",
                  }}
                >
                  {result.status || "submitted"}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ══════════════════════════════════════════════════════════════════
            INTELLIGENT POST-ASSESSMENT ACTION HUB (CLEAN & ON-DEMAND)
           ══════════════════════════════════════════════════════════════════ */}
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e2e8f0",
            borderRadius: 16,
            padding: "24px 28px",
            marginBottom: 24,
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.03)",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 18,
              flexWrap: "wrap",
              gap: 12,
            }}
          >
            <div>
              <div
                style={{
                  fontSize: 11,
                  fontWeight: 800,
                  textTransform: "uppercase",
                  letterSpacing: "0.6px",
                  color: "#6366f1",
                  marginBottom: 4,
                }}
              >
                Post-Assessment Learning Suite
              </div>
              <h2
                style={{
                  fontSize: 18,
                  fontWeight: 800,
                  color: "#1e293b",
                  margin: 0,
                }}
              >
                AI Insights &amp; Personalized Revision
              </h2>
            </div>
            <div
              style={{
                fontSize: 12,
                color: "#64748b",
                background: "#f8fafc",
                border: "1px solid #e2e8f0",
                padding: "6px 14px",
                borderRadius: 20,
                fontWeight: 600,
              }}
            >
              Available On-Demand · Click to explore or hide anytime
            </div>
          </div>

          {/* Action Cards Grid */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
              gap: 16,
            }}
          >
            {/* Card 1: AI Performance Analysis */}
            <div
              style={{
                border: showAISection ? "1.5px solid #6366f1" : "1px solid #e2e8f0",
                background: showAISection
                  ? "linear-gradient(180deg, #fbfaff 0%, #ffffff 100%)"
                  : "#ffffff",
                borderRadius: 14,
                padding: 20,
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                gap: 16,
                transition: "all 0.2s ease",
                boxShadow: showAISection
                  ? "0 4px 16px rgba(99, 102, 241, 0.08)"
                  : "none",
              }}
            >
              <div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: 12,
                  }}
                >
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 10,
                      background: "rgba(99, 102, 241, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Sparkles size={20} color="#4f46e5" />
                  </div>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      padding: "4px 9px",
                      borderRadius: 6,
                      background: showAISection
                        ? "#ede9fe"
                        : aiAnalysis
                        ? "#dcfce7"
                        : "#f1f5f9",
                      color: showAISection
                        ? "#6d28d9"
                        : aiAnalysis
                        ? "#15803d"
                        : "#475569",
                    }}
                  >
                    {showAISection
                      ? "Active View"
                      : aiAnalysis
                      ? "Analysis Cached"
                      : "Ready on Request"}
                  </span>
                </div>
                <h3
                  style={{
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#1e293b",
                    margin: "0 0 6px",
                  }}
                >
                  AI Performance &amp; Mastery Analysis
                </h3>
                <p
                  style={{
                    fontSize: 13,
                    color: "#64748b",
                    margin: 0,
                    lineHeight: 1.5,
                  }}
                >
                  In-depth cognitive evaluation of your responses, concept strengths, knowledge gaps, and an AI study roadmap.
                </p>
              </div>

              <button
                onClick={handleOpenAISection}
                disabled={generatingAI}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                  width: "100%",
                  background: showAISection
                    ? "#f8fafc"
                    : "linear-gradient(135deg, #4f46e5 0%, #6366f1 100%)",
                  color: showAISection ? "#475569" : "#ffffff",
                  border: showAISection ? "1px solid #cbd5e1" : "none",
                  borderRadius: 10,
                  padding: "11px 16px",
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: "pointer",
                  transition: "all 0.2s ease",
                  boxShadow: showAISection
                    ? "none"
                    : "0 3px 10px rgba(99, 102, 241, 0.25)",
                }}
              >
                {generatingAI ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Analyzing Responses...</span>
                  </>
                ) : showAISection ? (
                  <>
                    <ChevronUp size={16} />
                    <span>Hide Analysis</span>
                  </>
                ) : aiAnalysis ? (
                  <>
                    <Sparkles size={16} />
                    <span>View AI Analysis</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={16} />
                    <span>Analyze with AI</span>
                  </>
                )}
              </button>
            </div>

            {/* Card 2: Personalized Revision Pack */}
            <div
              style={{
                border: showRevisionSection
                  ? "1.5px solid #8b5cf6"
                  : "1px solid #e2e8f0",
                background: showRevisionSection
                  ? "linear-gradient(180deg, #fbfaff 0%, #ffffff 100%)"
                  : "#ffffff",
                borderRadius: 14,
                padding: 20,
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                gap: 16,
                transition: "all 0.2s ease",
                boxShadow: showRevisionSection
                  ? "0 4px 16px rgba(139, 92, 246, 0.08)"
                  : "none",
              }}
            >
              <div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: 12,
                  }}
                >
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 10,
                      background: "rgba(139, 92, 246, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <BookOpen size={20} color="#7c3aed" />
                  </div>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      padding: "4px 9px",
                      borderRadius: 6,
                      background: showRevisionSection
                        ? "#ede9fe"
                        : revisionPack
                        ? "#dcfce7"
                        : "#f1f5f9",
                      color: showRevisionSection
                        ? "#6d28d9"
                        : revisionPack
                        ? "#15803d"
                        : "#475569",
                    }}
                  >
                    {showRevisionSection
                      ? "Active View"
                      : revisionPack
                      ? "Pack Assembled"
                      : "Ready on Request"}
                  </span>
                </div>
                <h3
                  style={{
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#1e293b",
                    margin: "0 0 6px",
                  }}
                >
                  Review Assessment &amp; Revision Pack
                </h3>
                <p
                  style={{
                    fontSize: 13,
                    color: "#64748b",
                    margin: 0,
                    lineHeight: 1.5,
                  }}
                >
                  Identify weak areas and browse approved live learning resources (MIT OCW, docs, sandboxes) tailored to missed topics.
                </p>
              </div>

              <button
                onClick={handleOpenRevisionSection}
                disabled={loadingReview}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                  width: "100%",
                  background: showRevisionSection
                    ? "#f8fafc"
                    : "linear-gradient(135deg, #1e1b4b 0%, #4338ca 100%)",
                  color: showRevisionSection ? "#475569" : "#ffffff",
                  border: showRevisionSection ? "1px solid #cbd5e1" : "none",
                  borderRadius: 10,
                  padding: "11px 16px",
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: "pointer",
                  transition: "all 0.2s ease",
                  boxShadow: showRevisionSection
                    ? "none"
                    : "0 3px 10px rgba(30, 27, 75, 0.25)",
                }}
              >
                {loadingReview ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Loading Review...</span>
                  </>
                ) : showRevisionSection ? (
                  <>
                    <ChevronUp size={16} />
                    <span>Hide Review</span>
                  </>
                ) : revisionPack ? (
                  <>
                    <BookOpen size={16} />
                    <span>View Revision Pack</span>
                  </>
                ) : (
                  <>
                    <BookOpen size={16} />
                    <span>Review My Assessment</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* ══════════════════════════════════════════════════════════════════
            AI PERFORMANCE ANALYSIS SECTION (ON-DEMAND)
           ══════════════════════════════════════════════════════════════════ */}
        {showAISection && (
          <section id="ai-performance-section" style={{ marginBottom: 24 }}>
          {/* Card Container */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e6e9ef",
              borderRadius: 16,
              overflow: "hidden",
              boxShadow: "0 4px 24px rgba(98, 85, 231, 0.06)",
            }}
          >
            {/* AI Section Top Banner */}
            <div
              style={{
                background:
                  "linear-gradient(135deg, #4f46e5 0%, #6366f1 45%, #7c3aed 100%)",
                padding: "24px 32px",
                color: "#ffffff",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: 16,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 12,
                    background: "rgba(255, 255, 255, 0.2)",
                    backdropFilter: "blur(8px)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Sparkles size={24} color="#ffffff" />
                </div>
                <div>
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <h2
                      style={{
                        fontSize: 20,
                        fontWeight: 800,
                        margin: 0,
                        color: "#ffffff",
                      }}
                    >
                      AI Performance &amp; Mastery Analysis
                    </h2>
                    <span
                      style={{
                        background: "rgba(255, 255, 255, 0.25)",
                        padding: "3px 9px",
                        borderRadius: 12,
                        fontSize: 11,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.5px",
                      }}
                    >
                      Evalia AI Tutor
                    </span>
                  </div>
                  <p
                    style={{
                      fontSize: 13,
                      color: "rgba(255, 255, 255, 0.85)",
                      margin: "4px 0 0",
                    }}
                  >
                    In-depth cognitive evaluation, concept mastery breakdown
                    &amp; personalized study coaching
                  </p>
                </div>
              </div>

              {/* Banner Action Buttons */}
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                {aiAnalysis && !generatingAI && (
                  <button
                    onClick={() => handleGenerateAI(true)}
                    disabled={generatingAI}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 8,
                      background: "#ffffff",
                      color: "#4f46e5",
                      border: "none",
                      borderRadius: 10,
                      padding: "10px 18px",
                      fontWeight: 700,
                      fontSize: 13,
                      cursor: "pointer",
                      boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
                      transition: "all 0.2s ease",
                    }}
                  >
                    <RefreshCw size={14} /> Regenerate Analysis
                  </button>
                )}

                <button
                  onClick={() => setShowAISection(false)}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    background: "rgba(255, 255, 255, 0.18)",
                    color: "#ffffff",
                    border: "1px solid rgba(255, 255, 255, 0.3)",
                    borderRadius: 10,
                    padding: "10px 16px",
                    fontWeight: 600,
                    fontSize: 13,
                    cursor: "pointer",
                    transition: "all 0.2s ease",
                  }}
                >
                  <ChevronUp size={16} /> Hide Analysis
                </button>
              </div>
            </div>

            {/* Content Area */}
            <div style={{ padding: 32 }}>
              {/* State 1: Generating Loading Indicator */}
              {generatingAI && (
                <div style={{ textAlign: "center", padding: "48px 24px" }}>
                  <div
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: "50%",
                      background: "rgba(99, 102, 241, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 20px",
                    }}
                  >
                    <Loader2
                      size={32}
                      className="animate-spin"
                      style={{ color: "#6366f1" }}
                    />
                  </div>
                  <h3
                    style={{
                      fontSize: 17,
                      fontWeight: 800,
                      color: "#1d2536",
                      margin: "0 0 8px",
                    }}
                  >
                    Synthesizing Performance Analysis...
                  </h3>
                  <p
                    style={{
                      fontSize: 14,
                      color: "#6366f1",
                      fontWeight: 600,
                      margin: 0,
                    }}
                  >
                    {generationStep ||
                      "Processing test questions and generating educational insights..."}
                  </p>
                  <p style={{ fontSize: 12, color: "#94a3b8", marginTop: 8 }}>
                    Evalia AI is evaluating rubric alignment, question pacing,
                    and concept mastery.
                  </p>
                </div>
              )}

              {/* State 2: Error Notification */}
              {aiError && !generatingAI && (
                <div
                  style={{
                    padding: 16,
                    background: "#fef2f2",
                    border: "1px solid #fecaca",
                    borderRadius: 10,
                    marginBottom: 20,
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                  }}
                >
                  <AlertTriangle size={20} color="#dc2626" />
                  <div style={{ flex: 1, fontSize: 13, color: "#991b1b" }}>
                    <strong>Analysis Generation Notice:</strong> {aiError}
                  </div>
                  <button
                    onClick={() => handleGenerateAI(true)}
                    style={{
                      padding: "6px 14px",
                      background: "#dc2626",
                      color: "#fff",
                      border: "none",
                      borderRadius: 6,
                      fontSize: 12,
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    Try Again
                  </button>
                </div>
              )}

              {/* State 3: Not Generated Yet - CTA Card */}
              {!aiAnalysis && !generatingAI && (
                <div
                  style={{
                    textAlign: "center",
                    padding: "32px 24px",
                    background:
                      "linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)",
                    borderRadius: 12,
                    border: "1.5px dashed #cbd5e1",
                  }}
                >
                  <div
                    style={{
                      width: 56,
                      height: 56,
                      borderRadius: "50%",
                      background: "rgba(99, 102, 241, 0.12)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      margin: "0 auto 16px",
                    }}
                  >
                    <Brain size={28} style={{ color: "#6366f1" }} />
                  </div>

                  <h3
                    style={{
                      fontSize: 18,
                      fontWeight: 800,
                      color: "#1d2536",
                      margin: "0 0 8px",
                    }}
                  >
                    Unlock Your AI Performance Insights
                  </h3>
                  <p
                    style={{
                      fontSize: 14,
                      color: "#64748b",
                      margin: "0 auto 24px",
                      maxWidth: 520,
                      lineHeight: 1.5,
                    }}
                  >
                    Generate deep conceptual analytics of this assessment:
                    discover which topics you mastered, analyze missed questions
                    with intelligent coaching, and get an adaptive study plan
                    tailored to your results.
                  </p>

                  <button
                    onClick={() => handleGenerateAI(false)}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 10,
                      background:
                        "linear-gradient(135deg, #4f46e5 0%, #6366f1 100%)",
                      color: "#ffffff",
                      border: "none",
                      borderRadius: 10,
                      padding: "13px 28px",
                      fontWeight: 800,
                      fontSize: 14,
                      cursor: "pointer",
                      boxShadow: "0 4px 14px rgba(79, 70, 229, 0.35)",
                      transition: "transform 0.15s ease",
                    }}
                  >
                    <Sparkles size={16} /> Generate AI Performance Analysis
                  </button>
                </div>
              )}

              {/* State 4: Analysis Generated - Full Rich Dashboard */}
              {aiAnalysis && !generatingAI && (
                <div
                  style={{ display: "flex", flexDirection: "column", gap: 28 }}
                >
                  {/* Executive Summary Card */}
                  <div
                    style={{
                      background: "#f8fafc",
                      border: "1.5px solid #e2e8f0",
                      borderRadius: 12,
                      padding: 24,
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        flexWrap: "wrap",
                        gap: 12,
                        marginBottom: 12,
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 800,
                            color: "#6366f1",
                            textTransform: "uppercase",
                            letterSpacing: "0.5px",
                          }}
                        >
                          Executive Performance Review
                        </span>
                      </div>
                      <div
                        style={{
                          background: "#e0e7ff",
                          color: "#3730a3",
                          fontWeight: 800,
                          fontSize: 13,
                          padding: "5px 14px",
                          borderRadius: 20,
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 6,
                        }}
                      >
                        <Award size={14} />
                        {aiAnalysis.overallRating || "Performance Evaluated"}
                      </div>
                    </div>

                    <p
                      style={{
                        fontSize: 15,
                        color: "#1e293b",
                        lineHeight: 1.6,
                        margin: 0,
                        fontWeight: 500,
                      }}
                    >
                      {aiAnalysis.executiveSummary}
                    </p>

                    {aiAnalysis.generatedAt && (
                      <div
                        style={{
                          marginTop: 12,
                          fontSize: 11,
                          color: "#94a3b8",
                        }}
                      >
                        Analyzed on{" "}
                        {new Date(aiAnalysis.generatedAt).toLocaleString()}
                      </div>
                    )}
                  </div>

                  {/* Concept Mastery Progress Matrix */}
                  {Array.isArray(aiAnalysis.conceptMastery) &&
                    aiAnalysis.conceptMastery.length > 0 && (
                      <div>
                        <h3
                          style={{
                            fontSize: 16,
                            fontWeight: 800,
                            color: "#1d2536",
                            margin: "0 0 16px",
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                          }}
                        >
                          <Target size={18} color="#6366f1" /> Topic &amp;
                          Concept Mastery Matrix
                        </h3>
                        <div
                          style={{
                            display: "grid",
                            gridTemplateColumns:
                              "repeat(auto-fit, minmax(260px, 1fr))",
                            gap: 14,
                          }}
                        >
                          {aiAnalysis.conceptMastery.map(
                            (item: any, idx: number) => {
                              const pct = Number(item.masteryPercentage) || 0;
                              const isMastered =
                                item.status === "mastered" || pct >= 80;
                              const isDeveloping =
                                item.status === "developing" ||
                                (pct >= 50 && pct < 80);
                              const color = isMastered
                                ? "#16a34a"
                                : isDeveloping
                                  ? "#f59e0b"
                                  : "#ef4444";
                              const bg = isMastered
                                ? "#dcfce7"
                                : isDeveloping
                                  ? "#fef3c7"
                                  : "#fee2e2";

                              return (
                                <div
                                  key={idx}
                                  style={{
                                    background: "#ffffff",
                                    border: "1.5px solid #e2e8f0",
                                    borderRadius: 10,
                                    padding: 16,
                                  }}
                                >
                                  <div
                                    style={{
                                      display: "flex",
                                      justifyContent: "space-between",
                                      alignItems: "center",
                                      marginBottom: 8,
                                    }}
                                  >
                                    <span
                                      style={{
                                        fontWeight: 700,
                                        fontSize: 14,
                                        color: "#1e293b",
                                      }}
                                    >
                                      {item.concept}
                                    </span>
                                    <span
                                      style={{
                                        fontSize: 11,
                                        fontWeight: 800,
                                        color,
                                        background: bg,
                                        padding: "2px 8px",
                                        borderRadius: 6,
                                      }}
                                    >
                                      {isMastered
                                        ? "Mastered"
                                        : isDeveloping
                                          ? "Developing"
                                          : "Needs Review"}{" "}
                                      ({pct}%)
                                    </span>
                                  </div>
                                  <div
                                    style={{
                                      width: "100%",
                                      height: 6,
                                      background: "#f1f5f9",
                                      borderRadius: 4,
                                      overflow: "hidden",
                                      marginBottom: 8,
                                    }}
                                  >
                                    <div
                                      style={{
                                        width: `${Math.max(5, Math.min(100, pct))}%`,
                                        height: "100%",
                                        background: color,
                                        borderRadius: 4,
                                        transition: "width 0.6s ease",
                                      }}
                                    />
                                  </div>
                                  <p
                                    style={{
                                      fontSize: 12,
                                      color: "#64748b",
                                      margin: 0,
                                      lineHeight: 1.4,
                                    }}
                                  >
                                    {item.explanation}
                                  </p>
                                </div>
                              );
                            },
                          )}
                        </div>
                      </div>
                    )}

                  {/* Strengths & Growth Areas Grid */}
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fit, minmax(300px, 1fr))",
                      gap: 16,
                    }}
                  >
                    {/* Strengths */}
                    <div
                      style={{
                        background: "#f0fdf4",
                        border: "1.5px solid #bbf7d0",
                        borderRadius: 12,
                        padding: 20,
                      }}
                    >
                      <h4
                        style={{
                          fontSize: 15,
                          fontWeight: 800,
                          color: "#166534",
                          margin: "0 0 12px",
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                        }}
                      >
                        <CheckCircle2 size={18} color="#16a34a" /> Key Strengths
                        Demonstrated
                      </h4>
                      <ul
                        style={{
                          margin: 0,
                          paddingLeft: 20,
                          display: "flex",
                          flexDirection: "column",
                          gap: 8,
                        }}
                      >
                        {(aiAnalysis.strengths || []).map(
                          (str: string, idx: number) => (
                            <li
                              key={idx}
                              style={{
                                fontSize: 13,
                                color: "#14532d",
                                lineHeight: 1.4,
                                fontWeight: 500,
                              }}
                            >
                              {str}
                            </li>
                          ),
                        )}
                      </ul>
                    </div>

                    {/* Weaknesses / Growth Areas */}
                    <div
                      style={{
                        background: "#fffbeb",
                        border: "1.5px solid #fde68a",
                        borderRadius: 12,
                        padding: 20,
                      }}
                    >
                      <h4
                        style={{
                          fontSize: 15,
                          fontWeight: 800,
                          color: "#92400e",
                          margin: "0 0 12px",
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                        }}
                      >
                        <Lightbulb size={18} color="#d97706" /> Identified
                        Knowledge Gaps
                      </h4>
                      <ul
                        style={{
                          margin: 0,
                          paddingLeft: 20,
                          display: "flex",
                          flexDirection: "column",
                          gap: 8,
                        }}
                      >
                        {(aiAnalysis.weaknesses || []).map(
                          (wk: string, idx: number) => (
                            <li
                              key={idx}
                              style={{
                                fontSize: 13,
                                color: "#78350f",
                                lineHeight: 1.4,
                                fontWeight: 500,
                              }}
                            >
                              {wk}
                            </li>
                          ),
                        )}
                      </ul>
                    </div>
                  </div>

                  {/* Question-Level Intelligent Coaching Takeaways */}
                  {Array.isArray(aiAnalysis.questionFeedback) &&
                    aiAnalysis.questionFeedback.length > 0 && (
                      <div>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: 14,
                          }}
                        >
                          <h3
                            style={{
                              fontSize: 16,
                              fontWeight: 800,
                              color: "#1d2536",
                              margin: 0,
                              display: "flex",
                              alignItems: "center",
                              gap: 8,
                            }}
                          >
                            <GraduationCap size={18} color="#6366f1" />{" "}
                            Question-by-Question AI Coaching
                          </h3>
                          <span
                            style={{
                              fontSize: 12,
                              color: "#64748b",
                              fontWeight: 600,
                            }}
                          >
                            {aiAnalysis.questionFeedback.length} Coaching
                            Takeaways
                          </span>
                        </div>

                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 12,
                          }}
                        >
                          {aiAnalysis.questionFeedback.map(
                            (fb: any, idx: number) => {
                              const isExpanded =
                                expandedQuestions[fb.questionId || idx] ?? true;
                              return (
                                <div
                                  key={fb.questionId || idx}
                                  style={{
                                    background: "#ffffff",
                                    border: `1.5px solid ${fb.isCorrect ? "rgba(34, 197, 94, 0.35)" : "rgba(245, 158, 11, 0.4)"}`,
                                    borderRadius: 10,
                                    padding: "14px 16px",
                                  }}
                                >
                                  <div
                                    onClick={() =>
                                      toggleQuestionExpanded(
                                        fb.questionId || idx,
                                      )
                                    }
                                    style={{
                                      display: "flex",
                                      justifyContent: "space-between",
                                      alignItems: "center",
                                      cursor: "pointer",
                                      gap: 12,
                                    }}
                                  >
                                    <div
                                      style={{
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 10,
                                        flex: 1,
                                      }}
                                    >
                                      <span
                                        style={{
                                          fontSize: 11,
                                          fontWeight: 800,
                                          color: fb.isCorrect
                                            ? "#16a34a"
                                            : "#d97706",
                                          background: fb.isCorrect
                                            ? "#dcfce7"
                                            : "#fef3c7",
                                          padding: "2px 8px",
                                          borderRadius: 6,
                                          whiteSpace: "nowrap",
                                        }}
                                      >
                                        Q{idx + 1} ·{" "}
                                        {fb.isCorrect
                                          ? "Mastered"
                                          : "Revision Tip"}
                                      </span>
                                      <span
                                        style={{
                                          fontSize: 13,
                                          fontWeight: 700,
                                          color: "#1e293b",
                                          overflow: "hidden",
                                          textOverflow: "ellipsis",
                                          whiteSpace: "nowrap",
                                        }}
                                      >
                                        {fb.prompt}
                                      </span>
                                    </div>
                                    {isExpanded ? (
                                      <ChevronUp size={16} color="#64748b" />
                                    ) : (
                                      <ChevronDown size={16} color="#64748b" />
                                    )}
                                  </div>

                                  {isExpanded && (
                                    <div
                                      style={{
                                        marginTop: 10,
                                        paddingTop: 10,
                                        borderTop: "1px solid #f1f5f9",
                                      }}
                                    >
                                      <p
                                        style={{
                                          fontSize: 13,
                                          color: "#334155",
                                          margin: "0 0 6px",
                                          lineHeight: 1.5,
                                        }}
                                      >
                                        {fb.feedback}
                                      </p>
                                      {fb.keyTakeaway && (
                                        <div
                                          style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 6,
                                            fontSize: 12,
                                            color: "#6366f1",
                                            fontWeight: 700,
                                          }}
                                        >
                                          <Zap size={13} /> Takeaway:{" "}
                                          {fb.keyTakeaway}
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>
                              );
                            },
                          )}
                        </div>
                      </div>
                    )}

                  {/* Adaptive Study Plan & Next Steps */}
                  {aiAnalysis.studyPlan && (
                    <div
                      style={{
                        background:
                          "linear-gradient(180deg, #f8fafc 0%, #edf2f7 100%)",
                        border: "1.5px solid #cbd5e1",
                        borderRadius: 12,
                        padding: 24,
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          flexWrap: "wrap",
                          gap: 12,
                          marginBottom: 14,
                        }}
                      >
                        <h3
                          style={{
                            fontSize: 16,
                            fontWeight: 800,
                            color: "#1d2536",
                            margin: 0,
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                          }}
                        >
                          <BookOpen size={18} color="#6366f1" /> Personalized
                          Adaptive Study Plan
                        </h3>
                        {aiAnalysis.studyPlan.recommendedHours && (
                          <span
                            style={{
                              background: "#e2e8f0",
                              color: "#334155",
                              fontSize: 12,
                              fontWeight: 800,
                              padding: "4px 12px",
                              borderRadius: 12,
                            }}
                          >
                            ⏱ ~{aiAnalysis.studyPlan.recommendedHours} Hours
                            Targeted Review
                          </span>
                        )}
                      </div>

                      {/* Priority Topics */}
                      {Array.isArray(aiAnalysis.studyPlan.topicsToFocus) &&
                        aiAnalysis.studyPlan.topicsToFocus.length > 0 && (
                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 8,
                              flexWrap: "wrap",
                              marginBottom: 14,
                            }}
                          >
                            <span
                              style={{
                                fontSize: 12,
                                fontWeight: 700,
                                color: "#64748b",
                              }}
                            >
                              Priority Topics:
                            </span>
                            {aiAnalysis.studyPlan.topicsToFocus.map(
                              (t: string, idx: number) => (
                                <span
                                  key={idx}
                                  style={{
                                    background: "#ffffff",
                                    border: "1px solid #cbd5e1",
                                    padding: "3px 10px",
                                    borderRadius: 6,
                                    fontSize: 12,
                                    fontWeight: 700,
                                    color: "#1e293b",
                                  }}
                                >
                                  {t}
                                </span>
                              ),
                            )}
                          </div>
                        )}

                      {/* Action Steps */}
                      {Array.isArray(aiAnalysis.studyPlan.actionSteps) && (
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 8,
                            marginBottom: 14,
                          }}
                        >
                          {aiAnalysis.studyPlan.actionSteps.map(
                            (step: string, idx: number) => (
                              <div
                                key={idx}
                                style={{
                                  display: "flex",
                                  alignItems: "flex-start",
                                  gap: 10,
                                }}
                              >
                                <span
                                  style={{
                                    width: 22,
                                    height: 22,
                                    borderRadius: "50%",
                                    background: "#6366f1",
                                    color: "#ffffff",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    fontSize: 11,
                                    fontWeight: 800,
                                    flexShrink: 0,
                                    marginTop: 1,
                                  }}
                                >
                                  {idx + 1}
                                </span>
                                <span
                                  style={{
                                    fontSize: 13,
                                    color: "#334155",
                                    lineHeight: 1.5,
                                    fontWeight: 500,
                                  }}
                                >
                                  {step}
                                </span>
                              </div>
                            ),
                          )}
                        </div>
                      )}

                      {aiAnalysis.studyPlan.practiceSuggestions && (
                        <p
                          style={{
                            fontSize: 12,
                            color: "#64748b",
                            margin: 0,
                            fontStyle: "italic",
                            borderTop: "1px solid #e2e8f0",
                            paddingTop: 10,
                          }}
                        >
                          💡 Practice Tip:{" "}
                          {aiAnalysis.studyPlan.practiceSuggestions}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Pacing & Conduct Summary */}
                  {aiAnalysis.pacingAndConduct && (
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        background: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: 10,
                        padding: "14px 18px",
                        flexWrap: "wrap",
                        gap: 12,
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <Clock size={16} color="#6366f1" />
                        <div>
                          <span
                            style={{
                              fontSize: 11,
                              fontWeight: 700,
                              color: "#64748b",
                              textTransform: "uppercase",
                            }}
                          >
                            Exam Pacing
                          </span>
                          <div
                            style={{
                              fontSize: 13,
                              fontWeight: 700,
                              color: "#1e293b",
                            }}
                          >
                            {aiAnalysis.pacingAndConduct.pacingVerdict} (
                            {aiAnalysis.pacingAndConduct.timeSpentMinutes} mins
                            elapsed)
                          </div>
                        </div>
                      </div>

                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <ShieldCheck size={16} color="#16a34a" />
                        <div>
                          <span
                            style={{
                              fontSize: 11,
                              fontWeight: 700,
                              color: "#64748b",
                              textTransform: "uppercase",
                            }}
                          >
                            Conduct Reflection
                          </span>
                          <div
                            style={{
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#334155",
                              maxWidth: 500,
                            }}
                          >
                            {aiAnalysis.pacingAndConduct.conductNote}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </section>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            REVIEW MY ASSESSMENT & PERSONALIZED REVISION PACK SECTION
           ══════════════════════════════════════════════════════════════════ */}
        {showRevisionSection && (
          <section id="revision-pack-section" style={{ marginBottom: 24 }}>
          {/* Main Card Container */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e6e9ef",
              borderRadius: 16,
              overflow: "hidden",
              boxShadow: "0 4px 24px rgba(98, 85, 231, 0.06)",
            }}
          >
            {/* Header Banner */}
            <div
              style={{
                background:
                  "linear-gradient(135deg, #1e1b4b 0%, #312e81 40%, #4338ca 100%)",
                padding: "24px 32px",
                color: "#ffffff",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: 16,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 12,
                    background: "rgba(255, 255, 255, 0.15)",
                    backdropFilter: "blur(8px)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <BookOpen size={24} color="#a5b4fc" />
                </div>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <h2
                      style={{
                        fontSize: 20,
                        fontWeight: 800,
                        margin: 0,
                        color: "#ffffff",
                      }}
                    >
                      Review My Assessment
                    </h2>
                    <span
                      style={{
                        background: "rgba(165, 180, 252, 0.25)",
                        color: "#e0e7ff",
                        padding: "3px 9px",
                        borderRadius: 12,
                        fontSize: 11,
                        fontWeight: 700,
                        textTransform: "uppercase",
                        letterSpacing: "0.5px",
                      }}
                    >
                      Curriculum Remediation
                    </span>
                  </div>
                  <p
                    style={{
                      fontSize: 13,
                      color: "rgba(255, 255, 255, 0.85)",
                      margin: "4px 0 0",
                    }}
                  >
                    You have completed this assessment. We identified{" "}
                    <strong>
                      {assessmentReview?.areas?.length || 3} areas
                    </strong>{" "}
                    that could use further revision.
                  </p>
                </div>
              </div>

              {/* Banner Action Buttons */}
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                {/* Generate / Regenerate Revision Pack CTA */}
                <button
                  onClick={() => handleGenerateRevisionPack(Boolean(revisionPack))}
                  disabled={generatingPack}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 8,
                    background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
                    color: "#ffffff",
                    border: "none",
                    borderRadius: 10,
                    padding: "11px 20px",
                    fontWeight: 700,
                    fontSize: 13,
                    cursor: generatingPack ? "not-allowed" : "pointer",
                    boxShadow: "0 4px 14px rgba(99, 102, 241, 0.4)",
                    transition: "all 0.2s ease",
                    opacity: generatingPack ? 0.8 : 1,
                  }}
                >
                  {generatingPack ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Assembling Revision Pack...</span>
                    </>
                  ) : revisionPack ? (
                    <>
                      <RefreshCw size={16} />
                      <span>Regenerate Revision Pack</span>
                    </>
                  ) : (
                    <>
                      <Sparkles size={16} />
                      <span>Generate Revision Pack</span>
                    </>
                  )}
                </button>

                {/* Hide Review Button */}
                <button
                  onClick={() => setShowRevisionSection(false)}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    background: "rgba(255, 255, 255, 0.15)",
                    color: "#ffffff",
                    border: "1px solid rgba(255, 255, 255, 0.25)",
                    borderRadius: 10,
                    padding: "11px 16px",
                    fontWeight: 600,
                    fontSize: 13,
                    cursor: "pointer",
                    transition: "all 0.2s ease",
                  }}
                >
                  <ChevronUp size={16} /> Hide Review
                </button>
              </div>
            </div>

            {/* Generating Progress Indicator */}
            {generatingPack && (
              <div
                style={{
                  background: "#f0f4ff",
                  borderBottom: "1px solid #dbeafe",
                  padding: "16px 32px",
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                }}
              >
                <Loader2 size={18} className="animate-spin" color="#4f46e5" />
                <span
                  style={{
                    fontSize: 13,
                    color: "#3730a3",
                    fontWeight: 600,
                  }}
                >
                  {packStep || "Retrieving curated educational resources across variable web sources..."}
                </span>
              </div>
            )}

            {packError && (
              <div
                style={{
                  background: "#fef2f2",
                  borderBottom: "1px solid #fecaca",
                  padding: "12px 32px",
                  color: "#b91c1c",
                  fontSize: 13,
                  fontWeight: 600,
                }}
              >
                {packError}
              </div>
            )}

            {/* Review Areas Section */}
            <div style={{ padding: "28px 32px" }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: 16,
                  flexWrap: "wrap",
                  gap: 12,
                }}
              >
                <div>
                  <h3
                    style={{
                      fontSize: 16,
                      fontWeight: 800,
                      color: "#1e293b",
                      margin: 0,
                    }}
                  >
                    Identified Performance Areas
                  </h3>
                  <p
                    style={{
                      fontSize: 13,
                      color: "#64748b",
                      margin: "3px 0 0",
                    }}
                  >
                    Categorized based on your answered questions, rubric accuracy, and objective mastery.
                  </p>
                </div>
                {assessmentReview?.needsReviewCount !== undefined && (
                  <span
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      background:
                        assessmentReview.needsReviewCount > 0
                          ? "#fee2e2"
                          : "#ecfdf5",
                      color:
                        assessmentReview.needsReviewCount > 0
                          ? "#b91c1c"
                          : "#047857",
                      padding: "4px 12px",
                      borderRadius: 20,
                      border: `1px solid ${assessmentReview.needsReviewCount > 0 ? "#fca5a5" : "#a7f3d0"}`,
                    }}
                  >
                    {assessmentReview.needsReviewCount > 0
                      ? `${assessmentReview.needsReviewCount} Topic(s) Need Priority Review`
                      : "Solid Competency Across All Topics"}
                  </span>
                )}
              </div>

              {/* Areas Grid */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
                  gap: 16,
                }}
              >
                {(
                  assessmentReview?.areas || [
                    {
                      displayOrder: 1,
                      topic: "Database Normalization",
                      performance: "Needs Review",
                      performanceBadge: "needs_review",
                      accuracyPercentage: 33,
                      difficulty: "Hard",
                      learningObjective:
                        "Understand 1NF, 2NF, 3NF and elimination of functional & transitive dependencies.",
                      rationale:
                        "Encountered difficulties on composite key partial dependencies and 3NF normalization.",
                    },
                    {
                      displayOrder: 2,
                      topic: "SQL Joins",
                      performance: "Moderate",
                      performanceBadge: "moderate",
                      accuracyPercentage: 70,
                      difficulty: "Medium",
                      learningObjective:
                        "Distinguish between INNER, LEFT, RIGHT, and FULL OUTER joins.",
                      rationale:
                        "Demonstrated working knowledge with minor discrepancies on outer join WHERE clause filtering.",
                    },
                    {
                      displayOrder: 3,
                      topic: "Entity-Relationship Modeling",
                      performance: "Strong",
                      performanceBadge: "strong",
                      accuracyPercentage: 100,
                      difficulty: "Medium",
                      learningObjective:
                        "Model entities, cardinality, and bridge associative tables.",
                      rationale:
                        "Strong mastery demonstrated on entities, relationships, and crow's foot notation.",
                    },
                  ]
                ).map((area: any) => {
                  const isNeedsReview = area.performance === "Needs Review";
                  const isModerate = area.performance === "Moderate";
                  const badgeBg = isNeedsReview
                    ? "#fee2e2"
                    : isModerate
                      ? "#fef3c7"
                      : "#d1fae5";
                  const badgeColor = isNeedsReview
                    ? "#b91c1c"
                    : isModerate
                      ? "#b45309"
                      : "#047857";
                  const borderColor = isNeedsReview
                    ? "#fca5a5"
                    : isModerate
                      ? "#fcd34d"
                      : "#6ee7b7";
                  const icon = isNeedsReview ? (
                    <AlertTriangle size={14} color="#b91c1c" />
                  ) : isModerate ? (
                    <Target size={14} color="#b45309" />
                  ) : (
                    <CheckCircle2 size={14} color="#047857" />
                  );

                  return (
                    <div
                      key={area.id || area.topic}
                      style={{
                        background: isNeedsReview
                          ? "#fffaf9"
                          : isModerate
                            ? "#fffdf5"
                            : "#f6fbf9",
                        border: `1.5px solid ${borderColor}`,
                        borderRadius: 12,
                        padding: 18,
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "space-between",
                        transition: "transform 0.15s ease, box-shadow 0.15s ease",
                      }}
                    >
                      <div>
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: 8,
                            marginBottom: 8,
                          }}
                        >
                          <span
                            style={{
                              fontSize: 12,
                              fontWeight: 800,
                              color: "#64748b",
                              background: "rgba(0,0,0,0.04)",
                              width: 24,
                              height: 24,
                              borderRadius: "50%",
                              display: "inline-flex",
                              alignItems: "center",
                              justifyContent: "center",
                            }}
                          >
                            {area.displayOrder || 1}
                          </span>
                          <span
                            style={{
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 5,
                              fontSize: 11,
                              fontWeight: 800,
                              background: badgeBg,
                              color: badgeColor,
                              border: `1px solid ${borderColor}`,
                              padding: "3px 9px",
                              borderRadius: 12,
                              textTransform: "uppercase",
                              letterSpacing: "0.3px",
                            }}
                          >
                            {icon} Performance: {area.performance}
                          </span>
                        </div>

                        <h4
                          style={{
                            fontSize: 16,
                            fontWeight: 800,
                            color: "#1e293b",
                            margin: "0 0 6px",
                          }}
                        >
                          {area.topic}
                        </h4>

                        <p
                          style={{
                            fontSize: 12,
                            color: "#475569",
                            lineHeight: 1.5,
                            margin: "0 0 10px",
                          }}
                        >
                          {area.rationale}
                        </p>
                      </div>

                      <div
                        style={{
                          borderTop: "1px solid rgba(0,0,0,0.06)",
                          paddingTop: 10,
                          marginTop: 6,
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            fontSize: 11,
                            color: "#64748b",
                            fontWeight: 600,
                            marginBottom: 5,
                          }}
                        >
                          <span>Accuracy Meter</span>
                          <strong style={{ color: badgeColor }}>
                            {area.accuracyPercentage ?? 0}%
                          </strong>
                        </div>
                        <div
                          style={{
                            width: "100%",
                            height: 6,
                            background: "#e2e8f0",
                            borderRadius: 3,
                            overflow: "hidden",
                          }}
                        >
                          <div
                            style={{
                              width: `${Math.max(5, area.accuracyPercentage ?? 0)}%`,
                              height: "100%",
                              background: isNeedsReview
                                ? "#ef4444"
                                : isModerate
                                  ? "#f59e0b"
                                  : "#10b981",
                              borderRadius: 3,
                            }}
                          />
                        </div>

                        {area.learningObjective && (
                          <div
                            style={{
                              marginTop: 8,
                              fontSize: 11,
                              color: "#64748b",
                              fontStyle: "italic",
                            }}
                          >
                            🎯 Objective: {area.learningObjective}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ══════════════════════════════════════════════════════════════
                YOUR PERSONALIZED REVISION PACK VIEW (ORGANIZED DATA)
               ══════════════════════════════════════════════════════════════ */}
            {revisionPack && (
              <div
                style={{
                  borderTop: "2px solid #e0e7ff",
                  background: "#f8faff",
                  padding: "32px",
                }}
              >
                {/* Revision Pack Title & Source Badges */}
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    flexWrap: "wrap",
                    gap: 16,
                    marginBottom: 20,
                  }}
                >
                  <div>
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        marginBottom: 4,
                      }}
                    >
                      <h3
                        style={{
                          fontSize: 20,
                          fontWeight: 800,
                          color: "#1e1b4b",
                          margin: 0,
                        }}
                      >
                        Your Personalized Revision Pack
                      </h3>
                      <span
                        style={{
                          background: "#e0e7ff",
                          color: "#3730a3",
                          padding: "3px 10px",
                          borderRadius: 12,
                          fontSize: 11,
                          fontWeight: 700,
                        }}
                      >
                        {revisionPack.totalModules || revisionPack.modules?.length} Modules
                      </span>
                    </div>
                    <p
                      style={{
                        fontSize: 13,
                        color: "#475569",
                        margin: 0,
                      }}
                    >
                      Tailored learning resources dynamically scraped &amp; aggregated from variable academic sources based on your performance.
                    </p>
                  </div>

                  {/* Multi-Source Badges Row */}
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      flexWrap: "wrap",
                    }}
                  >
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 700,
                        color: "#475569",
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        padding: "4px 10px",
                        borderRadius: 6,
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                      }}
                    >
                      📚 Wikipedia Academic API
                    </span>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 700,
                        color: "#475569",
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        padding: "4px 10px",
                        borderRadius: 6,
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                      }}
                    >
                      🎥 MIT OCW / YouTube
                    </span>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 700,
                        color: "#475569",
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        padding: "4px 10px",
                        borderRadius: 6,
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                      }}
                    >
                      📖 Official Docs &amp; Articles
                    </span>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 700,
                        color: "#475569",
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        padding: "4px 10px",
                        borderRadius: 6,
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                      }}
                    >
                      ⚡ QuickRef &amp; Cheatsheets
                    </span>
                  </div>
                </div>

                {/* Module Selector Tabs */}
                {Array.isArray(revisionPack.modules) &&
                  revisionPack.modules.length > 0 && (
                    <div>
                      <div
                        style={{
                          display: "flex",
                          gap: 8,
                          borderBottom: "1.5px solid #e2e8f0",
                          paddingBottom: 0,
                          marginBottom: 24,
                          overflowX: "auto",
                        }}
                      >
                        {revisionPack.modules.map(
                          (mod: any, idx: number) => {
                            const isSelected = activeModuleTab === idx;
                            const isNR = mod.performance === "Needs Review";
                            const isMod = mod.performance === "Moderate";
                            const pillColor = isNR
                              ? "#ef4444"
                              : isMod
                                ? "#f59e0b"
                                : "#10b981";

                            return (
                              <button
                                key={mod.moduleId || idx}
                                onClick={() => setActiveModuleTab(idx)}
                                style={{
                                  background: isSelected ? "#ffffff" : "transparent",
                                  border: isSelected
                                    ? "1.5px solid #6366f1"
                                    : "1.5px solid transparent",
                                  borderBottom: isSelected
                                    ? "2px solid #ffffff"
                                    : "none",
                                  marginBottom: isSelected ? -2 : 0,
                                  borderRadius: "10px 10px 0 0",
                                  padding: "12px 18px",
                                  fontWeight: 700,
                                  fontSize: 13,
                                  color: isSelected ? "#1e1b4b" : "#64748b",
                                  cursor: "pointer",
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 8,
                                  whiteSpace: "nowrap",
                                  transition: "all 0.15s ease",
                                }}
                              >
                                <span
                                  style={{
                                    width: 8,
                                    height: 8,
                                    borderRadius: "50%",
                                    background: pillColor,
                                  }}
                                />
                                <span>
                                  {idx + 1}. {mod.topic}
                                </span>
                                <span
                                  style={{
                                    fontSize: 11,
                                    fontWeight: 700,
                                    background: isSelected ? "#eef2ff" : "#f1f5f9",
                                    color: isSelected ? "#4338ca" : "#64748b",
                                    padding: "2px 7px",
                                    borderRadius: 8,
                                  }}
                                >
                                  {mod.performance}
                                </span>
                              </button>
                            );
                          },
                        )}
                      </div>

                      {/* Module Learning Resources & Group Filter Hub */}
                      {(() => {
                        const activeMod =
                          revisionPack.modules[activeModuleTab] ||
                          revisionPack.modules[0];
                        if (!activeMod) return null;

                        const isNeedsReview =
                          activeMod.performance === "Needs Review";
                        const isModerate =
                          activeMod.performance === "Moderate";

                        // Determine target modules based on search scope
                        const targetModules =
                          searchScope === "all"
                            ? revisionPack.modules
                            : [activeMod];

                        // Calculate resource counts across target modules
                        const totalVideosCount = targetModules.reduce(
                          (acc: number, m: any) =>
                            acc + (m.videoTutorials?.length || 0),
                          0,
                        );
                        const totalDocsCount = targetModules.reduce(
                          (acc: number, m: any) =>
                            acc +
                            (m.documentationAndArticles?.length || 0) +
                            (m.liveAcademicContext ? 1 : 0),
                          0,
                        );
                        const totalCheatsheetsCount = targetModules.reduce(
                          (acc: number, m: any) =>
                            acc + (m.cheatSheetsAndRules?.length || 0),
                          0,
                        );
                        const totalResourcesCount =
                          totalVideosCount +
                          totalDocsCount +
                          totalCheatsheetsCount;

                        // Check if any matching resource exists across modules
                        let grandTotalMatches = 0;

                        return (
                          <div
                            style={{
                              display: "flex",
                              flexDirection: "column",
                              gap: 20,
                            }}
                          >
                            {/* ══════════════════════════════════════════════════════
                                SEARCH & GROUP FILTER CONTROL PANEL
                               ══════════════════════════════════════════════════════ */}
                            <div
                              style={{
                                background: "#ffffff",
                                border: "1px solid #e2e8f0",
                                borderRadius: 14,
                                padding: "18px 22px",
                                boxShadow: "0 2px 8px rgba(0, 0, 0, 0.02)",
                                display: "flex",
                                flexDirection: "column",
                                gap: 14,
                              }}
                            >
                              {/* Search Bar & Scope Toggle */}
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  flexWrap: "wrap",
                                  gap: 12,
                                }}
                              >
                                <div
                                  style={{
                                    position: "relative",
                                    flex: "1 1 300px",
                                  }}
                                >
                                  <Search
                                    size={16}
                                    color="#94a3b8"
                                    style={{
                                      position: "absolute",
                                      left: 14,
                                      top: "50%",
                                      transform: "translateY(-50%)",
                                    }}
                                  />
                                  <input
                                    type="text"
                                    placeholder="Search resources, topics, platforms, keywords..."
                                    value={resourceSearchQuery}
                                    onChange={(e) =>
                                      setResourceSearchQuery(e.target.value)
                                    }
                                    style={{
                                      width: "100%",
                                      padding: "10px 36px 10px 38px",
                                      borderRadius: 10,
                                      border: "1.5px solid #e2e8f0",
                                      fontSize: 13,
                                      color: "#1e293b",
                                      outline: "none",
                                      background: "#f8fafc",
                                      transition: "all 0.15s ease",
                                    }}
                                  />
                                  {resourceSearchQuery && (
                                    <button
                                      onClick={() => setResourceSearchQuery("")}
                                      title="Clear search"
                                      style={{
                                        position: "absolute",
                                        right: 12,
                                        top: "50%",
                                        transform: "translateY(-50%)",
                                        background: "none",
                                        border: "none",
                                        color: "#94a3b8",
                                        cursor: "pointer",
                                        padding: 2,
                                        display: "flex",
                                        alignItems: "center",
                                      }}
                                    >
                                      <X size={15} />
                                    </button>
                                  )}
                                </div>

                                {/* Scope Toggle */}
                                <div
                                  style={{
                                    display: "inline-flex",
                                    background: "#f1f5f9",
                                    padding: 3,
                                    borderRadius: 8,
                                    gap: 2,
                                  }}
                                >
                                  <button
                                    onClick={() => setSearchScope("current")}
                                    style={{
                                      background:
                                        searchScope === "current"
                                          ? "#ffffff"
                                          : "transparent",
                                      color:
                                        searchScope === "current"
                                          ? "#1e293b"
                                          : "#64748b",
                                      boxShadow:
                                        searchScope === "current"
                                          ? "0 1px 4px rgba(0,0,0,0.06)"
                                          : "none",
                                      border: "none",
                                      borderRadius: 6,
                                      padding: "6px 12px",
                                      fontSize: 12,
                                      fontWeight: 700,
                                      cursor: "pointer",
                                      transition: "all 0.15s ease",
                                    }}
                                  >
                                    Current Topic ({activeMod.topic})
                                  </button>
                                  <button
                                    onClick={() => setSearchScope("all")}
                                    style={{
                                      background:
                                        searchScope === "all"
                                          ? "#ffffff"
                                          : "transparent",
                                      color:
                                        searchScope === "all"
                                          ? "#1e293b"
                                          : "#64748b",
                                      boxShadow:
                                        searchScope === "all"
                                          ? "0 1px 4px rgba(0,0,0,0.06)"
                                          : "none",
                                      border: "none",
                                      borderRadius: 6,
                                      padding: "6px 12px",
                                      fontSize: 12,
                                      fontWeight: 700,
                                      cursor: "pointer",
                                      transition: "all 0.15s ease",
                                    }}
                                  >
                                    All Topics Across Pack
                                  </button>
                                </div>
                              </div>

                              {/* Group Filter Pills */}
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 8,
                                  overflowX: "auto",
                                  paddingBottom: 2,
                                }}
                              >
                                <span
                                  style={{
                                    fontSize: 12,
                                    fontWeight: 700,
                                    color: "#64748b",
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: 4,
                                    marginRight: 4,
                                    whiteSpace: "nowrap",
                                  }}
                                >
                                  <Filter size={13} /> Group Filter:
                                </span>

                                {[
                                  {
                                    id: "all",
                                    label: "All Resources",
                                    count: totalResourcesCount,
                                  },
                                  {
                                    id: "video",
                                    label: "🎥 Videos",
                                    count: totalVideosCount,
                                  },
                                  {
                                    id: "doc",
                                    label: "📖 Articles & Docs",
                                    count: totalDocsCount,
                                  },
                                  {
                                    id: "cheatsheet",
                                    label: "⚡ Cheatsheets",
                                    count: totalCheatsheetsCount,
                                  },
                                ].map((tab) => {
                                  const isSelected =
                                    resourceTypeFilter === tab.id;
                                  return (
                                    <button
                                      key={tab.id}
                                      onClick={() =>
                                        setResourceTypeFilter(tab.id as any)
                                      }
                                      style={{
                                        background: isSelected
                                          ? "#4f46e5"
                                          : "#f8fafc",
                                        color: isSelected
                                          ? "#ffffff"
                                          : "#475569",
                                        border: isSelected
                                          ? "1.5px solid #4f46e5"
                                          : "1.5px solid #e2e8f0",
                                        borderRadius: 20,
                                        padding: "6px 13px",
                                        fontSize: 12,
                                        fontWeight: 700,
                                        cursor: "pointer",
                                        display: "inline-flex",
                                        alignItems: "center",
                                        gap: 6,
                                        whiteSpace: "nowrap",
                                        transition: "all 0.15s ease",
                                      }}
                                    >
                                      <span>{tab.label}</span>
                                      <span
                                        style={{
                                          fontSize: 10,
                                          fontWeight: 800,
                                          background: isSelected
                                            ? "rgba(255,255,255,0.25)"
                                            : "#e2e8f0",
                                          color: isSelected
                                            ? "#ffffff"
                                            : "#475569",
                                          padding: "1px 6px",
                                          borderRadius: 10,
                                        }}
                                      >
                                        {tab.count}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                            {/* Focus Strategy Banner (Shown for active topic when current scope is selected) */}
                            {searchScope === "current" && (
                              <div
                                style={{
                                  background: isNeedsReview
                                    ? "linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)"
                                    : isModerate
                                      ? "linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)"
                                      : "linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%)",
                                  border: `1px solid ${isNeedsReview ? "#fca5a5" : isModerate ? "#fcd34d" : "#6ee7b7"}`,
                                  borderRadius: 12,
                                  padding: "18px 24px",
                                  display: "flex",
                                  alignItems: "flex-start",
                                  gap: 14,
                                }}
                              >
                                <div
                                  style={{
                                    width: 38,
                                    height: 38,
                                    borderRadius: 10,
                                    background: "#ffffff",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
                                    flexShrink: 0,
                                  }}
                                >
                                  {isNeedsReview ? (
                                    <AlertTriangle size={20} color="#ef4444" />
                                  ) : isModerate ? (
                                    <Target size={20} color="#f59e0b" />
                                  ) : (
                                    <CheckCircle2 size={20} color="#10b981" />
                                  )}
                                </div>
                                <div style={{ flex: 1 }}>
                                  <div
                                    style={{
                                      display: "flex",
                                      alignItems: "center",
                                      gap: 10,
                                      marginBottom: 4,
                                      flexWrap: "wrap",
                                    }}
                                  >
                                    <h4
                                      style={{
                                        fontSize: 15,
                                        fontWeight: 800,
                                        color: "#1e293b",
                                        margin: 0,
                                      }}
                                    >
                                      Focus Tier:{" "}
                                      {activeMod.focusStrategy?.tier ||
                                        (isNeedsReview
                                          ? "Foundational Recovery & Visual Walkthroughs"
                                          : isModerate
                                            ? "Core Refinement & Edge-Case Drills"
                                            : "Advanced Optimization & Architecture")}
                                    </h4>
                                    <span
                                      style={{
                                        fontSize: 12,
                                        fontWeight: 700,
                                        color: "#475569",
                                        background: "#ffffff",
                                        padding: "2px 8px",
                                        borderRadius: 6,
                                        border: "1px solid rgba(0,0,0,0.08)",
                                      }}
                                    >
                                      ⏱️ Est. Study Time:{" "}
                                      {activeMod.studyEstimatedHours || 2} hours
                                    </span>
                                  </div>
                                  <p
                                    style={{
                                      fontSize: 13,
                                      color: "#334155",
                                      lineHeight: 1.5,
                                      margin: 0,
                                    }}
                                  >
                                    {activeMod.focusStrategy?.description ||
                                      "Follow the structured multi-source learning sequence below to systematically reinforce your comprehension."}
                                  </p>
                                </div>
                              </div>
                            )}

                            {/* Render Filtered Modules & Resources */}
                            {targetModules.map((mod: any, mIdx: number) => {
                              const q = resourceSearchQuery.trim().toLowerCase();

                              // Filter Videos
                              const filteredVideos = (
                                mod.videoTutorials || []
                              ).filter((vid: any) => {
                                if (
                                  resourceTypeFilter !== "all" &&
                                  resourceTypeFilter !== "video"
                                )
                                  return false;
                                if (!q) return true;
                                return (
                                  vid.title?.toLowerCase().includes(q) ||
                                  vid.platform?.toLowerCase().includes(q) ||
                                  vid.level?.toLowerCase().includes(q) ||
                                  mod.topic?.toLowerCase().includes(q)
                                );
                              });

                              // Filter Docs
                              const filteredDocs = (
                                mod.documentationAndArticles || []
                              ).filter((doc: any) => {
                                if (
                                  resourceTypeFilter !== "all" &&
                                  resourceTypeFilter !== "doc"
                                )
                                  return false;
                                if (!q) return true;
                                return (
                                  doc.title?.toLowerCase().includes(q) ||
                                  doc.source?.toLowerCase().includes(q) ||
                                  doc.extract?.toLowerCase().includes(q) ||
                                  mod.topic?.toLowerCase().includes(q)
                                );
                              });

                              // Filter Cheatsheets
                              const filteredCheatsheets = (
                                mod.cheatSheetsAndRules || []
                              ).filter((cs: any) => {
                                if (
                                  resourceTypeFilter !== "all" &&
                                  resourceTypeFilter !== "cheatsheet"
                                )
                                  return false;
                                if (!q) return true;
                                return (
                                  cs.title?.toLowerCase().includes(q) ||
                                  cs.source?.toLowerCase().includes(q) ||
                                  cs.keyPoints?.some((pt: string) =>
                                    pt.toLowerCase().includes(q),
                                  ) ||
                                  mod.topic?.toLowerCase().includes(q)
                                );
                              });

                              // Filter Academic Context
                              const showAcademic =
                                mod.liveAcademicContext &&
                                (resourceTypeFilter === "all" ||
                                  resourceTypeFilter === "doc") &&
                                (!q ||
                                  mod.liveAcademicContext.title
                                    ?.toLowerCase()
                                    .includes(q) ||
                                  mod.liveAcademicContext.extract
                                    ?.toLowerCase()
                                    .includes(q) ||
                                  mod.topic?.toLowerCase().includes(q));

                              const moduleMatchCount =
                                filteredVideos.length +
                                filteredDocs.length +
                                filteredCheatsheets.length +
                                (showAcademic ? 1 : 0);

                              grandTotalMatches += moduleMatchCount;

                              if (moduleMatchCount === 0) return null;

                              return (
                                <div
                                  key={mod.moduleId || mIdx}
                                  style={{
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: 18,
                                    marginTop:
                                      searchScope === "all" && mIdx > 0 ? 12 : 0,
                                  }}
                                >
                                  {/* Topic Subheader when viewing all topics */}
                                  {searchScope === "all" && (
                                    <div
                                      style={{
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "space-between",
                                        borderBottom: "2px solid #e0e7ff",
                                        paddingBottom: 8,
                                        marginTop: 8,
                                      }}
                                    >
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          gap: 10,
                                        }}
                                      >
                                        <span
                                          style={{
                                            fontSize: 12,
                                            fontWeight: 800,
                                            background: "#4f46e5",
                                            color: "#ffffff",
                                            padding: "2px 8px",
                                            borderRadius: 6,
                                          }}
                                        >
                                          Topic {mIdx + 1}
                                        </span>
                                        <h4
                                          style={{
                                            fontSize: 16,
                                            fontWeight: 800,
                                            color: "#1e1b4b",
                                            margin: 0,
                                          }}
                                        >
                                          {mod.topic}
                                        </h4>
                                      </div>
                                      <span
                                        style={{
                                          fontSize: 12,
                                          fontWeight: 700,
                                          color: "#64748b",
                                        }}
                                      >
                                        {moduleMatchCount} resources matched
                                      </span>
                                    </div>
                                  )}

                                  {/* 1. Live Academic Extract (Wikipedia REST API) */}
                                  {showAcademic && (
                                    <div
                                      style={{
                                        background: "#ffffff",
                                        border: "1px solid #e2e8f0",
                                        borderRadius: 12,
                                        padding: "20px 24px",
                                        boxShadow: "0 2px 8px rgba(0,0,0,0.02)",
                                      }}
                                    >
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "space-between",
                                          gap: 12,
                                          marginBottom: 10,
                                          flexWrap: "wrap",
                                        }}
                                      >
                                        <div
                                          style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 8,
                                          }}
                                        >
                                          <span
                                            style={{
                                              fontSize: 11,
                                              fontWeight: 800,
                                              color: "#475569",
                                              background: "#f1f5f9",
                                              padding: "3px 8px",
                                              borderRadius: 6,
                                              textTransform: "uppercase",
                                            }}
                                          >
                                            Live Academic Reference
                                          </span>
                                          <h5
                                            style={{
                                              fontSize: 14,
                                              fontWeight: 800,
                                              color: "#0f172a",
                                              margin: 0,
                                            }}
                                          >
                                            {mod.liveAcademicContext.title}
                                          </h5>
                                        </div>

                                        {/* Action Buttons: Read in System & External */}
                                        <div
                                          style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 8,
                                          }}
                                        >
                                          <button
                                            onClick={() =>
                                              setActiveDocModal({
                                                title:
                                                  mod.liveAcademicContext.title,
                                                source:
                                                  "Wikipedia Academic Reference",
                                                url: mod.liveAcademicContext.url,
                                                extract:
                                                  mod.liveAcademicContext
                                                    .extract,
                                                topic: mod.topic,
                                                readingTime: "4 min read",
                                              })
                                            }
                                            style={{
                                              fontSize: 12,
                                              fontWeight: 700,
                                              color: "#ffffff",
                                              background: "#4f46e5",
                                              border: "none",
                                              borderRadius: 6,
                                              padding: "6px 12px",
                                              display: "inline-flex",
                                              alignItems: "center",
                                              gap: 5,
                                              cursor: "pointer",
                                              boxShadow:
                                                "0 2px 6px rgba(79, 70, 229, 0.25)",
                                            }}
                                          >
                                            <BookOpen size={13} /> Read in
                                            System
                                          </button>
                                          <a
                                            href={mod.liveAcademicContext.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            title="Open on Wikipedia"
                                            style={{
                                              fontSize: 12,
                                              fontWeight: 700,
                                              color: "#4f46e5",
                                              background: "#eef2ff",
                                              borderRadius: 6,
                                              padding: "6px 10px",
                                              textDecoration: "none",
                                              display: "inline-flex",
                                              alignItems: "center",
                                              gap: 4,
                                            }}
                                          >
                                            Wikipedia{" "}
                                            <ExternalLink size={12} />
                                          </a>
                                        </div>
                                      </div>
                                      <p
                                        style={{
                                          fontSize: 13,
                                          color: "#475569",
                                          lineHeight: 1.6,
                                          margin: 0,
                                        }}
                                      >
                                        {mod.liveAcademicContext.extract}
                                      </p>
                                    </div>
                                  )}

                                  {/* 2. Video Tutorials & Visual Walkthroughs */}
                                  {filteredVideos.length > 0 && (
                                    <div>
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          gap: 8,
                                          marginBottom: 12,
                                        }}
                                      >
                                        <Video size={18} color="#e11d48" />
                                        <h5
                                          style={{
                                            fontSize: 14,
                                            fontWeight: 800,
                                            color: "#1e293b",
                                            margin: 0,
                                          }}
                                        >
                                          Video Tutorials &amp; Visual
                                          Walkthroughs
                                        </h5>
                                        <span
                                          style={{
                                            fontSize: 11,
                                            fontWeight: 700,
                                            color: "#64748b",
                                          }}
                                        >
                                          ({filteredVideos.length} curated)
                                        </span>
                                      </div>

                                      <div
                                        style={{
                                          display: "grid",
                                          gridTemplateColumns:
                                            "repeat(auto-fit, minmax(280px, 1fr))",
                                          gap: 14,
                                        }}
                                      >
                                        {filteredVideos.map(
                                          (vid: any, vIdx: number) => {
                                            const isWatched =
                                              watchedVideos[vid.title];
                                            return (
                                              <div
                                                key={vIdx}
                                                style={{
                                                  background: "#ffffff",
                                                  border: isWatched
                                                    ? "1.5px solid #86efac"
                                                    : "1px solid #fecdd3",
                                                  borderRadius: 10,
                                                  padding: 16,
                                                  display: "flex",
                                                  flexDirection: "column",
                                                  justifyContent:
                                                    "space-between",
                                                  boxShadow:
                                                    "0 2px 6px rgba(225, 29, 72, 0.03)",
                                                }}
                                              >
                                                <div>
                                                  <div
                                                    style={{
                                                      display: "flex",
                                                      alignItems: "center",
                                                      justifyContent:
                                                        "space-between",
                                                      marginBottom: 8,
                                                    }}
                                                  >
                                                    <span
                                                      style={{
                                                        fontSize: 11,
                                                        fontWeight: 800,
                                                        color: "#e11d48",
                                                        background: "#fff1f2",
                                                        padding: "2px 8px",
                                                        borderRadius: 6,
                                                      }}
                                                    >
                                                      {vid.platform}
                                                    </span>
                                                    <div
                                                      style={{
                                                        display: "flex",
                                                        alignItems: "center",
                                                        gap: 6,
                                                      }}
                                                    >
                                                      {isWatched && (
                                                        <span
                                                          style={{
                                                            fontSize: 10,
                                                            fontWeight: 800,
                                                            color: "#16a34a",
                                                            background:
                                                              "#dcfce7",
                                                            padding: "2px 6px",
                                                            borderRadius: 4,
                                                            display:
                                                              "inline-flex",
                                                            alignItems:
                                                              "center",
                                                            gap: 3,
                                                          }}
                                                        >
                                                          <Check size={11} />{" "}
                                                          Watched
                                                        </span>
                                                      )}
                                                      <span
                                                        style={{
                                                          fontSize: 11,
                                                          fontWeight: 700,
                                                          color: "#64748b",
                                                        }}
                                                      >
                                                        ⏱️ {vid.duration}
                                                      </span>
                                                    </div>
                                                  </div>
                                                  <h6
                                                    style={{
                                                      fontSize: 13,
                                                      fontWeight: 700,
                                                      color: "#0f172a",
                                                      margin: "0 0 6px",
                                                      lineHeight: 1.4,
                                                    }}
                                                  >
                                                    {vid.title}
                                                  </h6>
                                                  <span
                                                    style={{
                                                      fontSize: 11,
                                                      color: "#64748b",
                                                    }}
                                                  >
                                                    Level: {vid.level}
                                                  </span>
                                                </div>

                                                {/* Action Buttons */}
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: 8,
                                                    marginTop: 14,
                                                  }}
                                                >
                                                  <button
                                                    onClick={() =>
                                                      setActiveVideoModal({
                                                        title: vid.title,
                                                        platform: vid.platform,
                                                        url: vid.url,
                                                        duration: vid.duration,
                                                        level: vid.level,
                                                        topic: mod.topic,
                                                      })
                                                    }
                                                    style={{
                                                      flex: 1,
                                                      display: "inline-flex",
                                                      alignItems: "center",
                                                      justifyContent: "center",
                                                      gap: 6,
                                                      background: isWatched
                                                        ? "#059669"
                                                        : "#e11d48",
                                                      color: "#ffffff",
                                                      borderRadius: 7,
                                                      padding: "8px 12px",
                                                      fontSize: 12,
                                                      fontWeight: 700,
                                                      border: "none",
                                                      cursor: "pointer",
                                                      boxShadow:
                                                        "0 2px 8px rgba(225, 29, 72, 0.25)",
                                                      transition:
                                                        "all 0.15s ease",
                                                    }}
                                                  >
                                                    <Play
                                                      size={13}
                                                      fill="#ffffff"
                                                    />{" "}
                                                    Watch in System
                                                  </button>
                                                  <a
                                                    href={vid.url}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    title="Open on Platform"
                                                    style={{
                                                      display: "inline-flex",
                                                      alignItems: "center",
                                                      justifyContent: "center",
                                                      width: 34,
                                                      height: 34,
                                                      borderRadius: 7,
                                                      background: "#fff1f2",
                                                      border:
                                                        "1px solid #fecdd3",
                                                      color: "#e11d48",
                                                      textDecoration: "none",
                                                    }}
                                                  >
                                                    <ExternalLink size={13} />
                                                  </a>
                                                </div>
                                              </div>
                                            );
                                          },
                                        )}
                                      </div>
                                    </div>
                                  )}

                                  {/* 2. Documentation & Articles */}
                                  {filteredDocs.length > 0 && (
                                    <div>
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          gap: 8,
                                          marginBottom: 12,
                                        }}
                                      >
                                        <BookOpen size={18} color="#2563eb" />
                                        <h5
                                          style={{
                                            fontSize: 14,
                                            fontWeight: 800,
                                            color: "#1e293b",
                                            margin: 0,
                                          }}
                                        >
                                          Official Technical Documentation &amp;
                                          Articles
                                        </h5>
                                        <span
                                          style={{
                                            fontSize: 11,
                                            fontWeight: 700,
                                            color: "#64748b",
                                          }}
                                        >
                                          ({filteredDocs.length} guides)
                                        </span>
                                      </div>

                                      <div
                                        style={{
                                          display: "grid",
                                          gridTemplateColumns:
                                            "repeat(auto-fit, minmax(280px, 1fr))",
                                          gap: 14,
                                        }}
                                      >
                                        {filteredDocs.map(
                                          (doc: any, dIdx: number) => {
                                            const isRead = readDocs[doc.title];
                                            return (
                                              <div
                                                key={dIdx}
                                                style={{
                                                  background: "#ffffff",
                                                  border: isRead
                                                    ? "1.5px solid #86efac"
                                                    : "1px solid #bfdbfe",
                                                  borderRadius: 10,
                                                  padding: 16,
                                                  display: "flex",
                                                  flexDirection: "column",
                                                  justifyContent:
                                                    "space-between",
                                                }}
                                              >
                                                <div>
                                                  <div
                                                    style={{
                                                      display: "flex",
                                                      alignItems: "center",
                                                      justifyContent:
                                                        "space-between",
                                                      marginBottom: 8,
                                                    }}
                                                  >
                                                    <span
                                                      style={{
                                                        fontSize: 11,
                                                        fontWeight: 800,
                                                        color: "#2563eb",
                                                        background: "#eff6ff",
                                                        padding: "2px 8px",
                                                        borderRadius: 6,
                                                      }}
                                                    >
                                                      {doc.source}
                                                    </span>
                                                    <div
                                                      style={{
                                                        display: "flex",
                                                        alignItems: "center",
                                                        gap: 6,
                                                      }}
                                                    >
                                                      {isRead && (
                                                        <span
                                                          style={{
                                                            fontSize: 10,
                                                            fontWeight: 800,
                                                            color: "#16a34a",
                                                            background:
                                                              "#dcfce7",
                                                            padding: "2px 6px",
                                                            borderRadius: 4,
                                                            display:
                                                              "inline-flex",
                                                            alignItems:
                                                              "center",
                                                            gap: 3,
                                                          }}
                                                        >
                                                          <Check size={11} />{" "}
                                                          Read
                                                        </span>
                                                      )}
                                                      <span
                                                        style={{
                                                          fontSize: 11,
                                                          fontWeight: 700,
                                                          color: "#64748b",
                                                        }}
                                                      >
                                                        {doc.difficulty}
                                                      </span>
                                                    </div>
                                                  </div>
                                                  <h6
                                                    style={{
                                                      fontSize: 13,
                                                      fontWeight: 700,
                                                      color: "#0f172a",
                                                      margin: "0 0 6px",
                                                    }}
                                                  >
                                                    {doc.title}
                                                  </h6>
                                                  <p
                                                    style={{
                                                      fontSize: 12,
                                                      color: "#475569",
                                                      margin: 0,
                                                      lineHeight: 1.4,
                                                    }}
                                                  >
                                                    {doc.extract}
                                                  </p>
                                                </div>

                                                {/* Action Buttons */}
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: 8,
                                                    marginTop: 14,
                                                  }}
                                                >
                                                  <button
                                                    onClick={() =>
                                                      setActiveDocModal({
                                                        title: doc.title,
                                                        source: doc.source,
                                                        url: doc.url,
                                                        difficulty:
                                                          doc.difficulty,
                                                        extract: doc.extract,
                                                        topic: mod.topic,
                                                        readingTime:
                                                          "3 min read",
                                                      })
                                                    }
                                                    style={{
                                                      flex: 1,
                                                      display: "inline-flex",
                                                      alignItems: "center",
                                                      justifyContent: "center",
                                                      gap: 6,
                                                      background: isRead
                                                        ? "#059669"
                                                        : "#2563eb",
                                                      color: "#ffffff",
                                                      borderRadius: 7,
                                                      padding: "8px 12px",
                                                      fontSize: 12,
                                                      fontWeight: 700,
                                                      border: "none",
                                                      cursor: "pointer",
                                                      boxShadow:
                                                        "0 2px 8px rgba(37, 99, 235, 0.25)",
                                                      transition:
                                                        "all 0.15s ease",
                                                    }}
                                                  >
                                                    <BookOpen size={13} /> Read
                                                    in System
                                                  </button>
                                                  <a
                                                    href={doc.url}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    title="Open Original Source"
                                                    style={{
                                                      display: "inline-flex",
                                                      alignItems: "center",
                                                      justifyContent: "center",
                                                      width: 34,
                                                      height: 34,
                                                      borderRadius: 7,
                                                      background: "#eff6ff",
                                                      border:
                                                        "1px solid #bfdbfe",
                                                      color: "#2563eb",
                                                      textDecoration: "none",
                                                    }}
                                                  >
                                                    <ExternalLink size={13} />
                                                  </a>
                                                </div>
                                              </div>
                                            );
                                          },
                                        )}
                                      </div>
                                    </div>
                                  )}

                                  {/* 5. Cheatsheets & Golden Rules */}
                                  {filteredCheatsheets.length > 0 && (
                                    <div
                                      style={{
                                        background: "#ffffff",
                                        border: "1px solid #c7d2fe",
                                        borderRadius: 12,
                                        padding: "20px 24px",
                                      }}
                                    >
                                      <div
                                        style={{
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "space-between",
                                          gap: 10,
                                          marginBottom: 12,
                                          flexWrap: "wrap",
                                        }}
                                      >
                                        <div
                                          style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 8,
                                          }}
                                        >
                                          <BookmarkCheck
                                            size={18}
                                            color="#4f46e5"
                                          />
                                          <h5
                                            style={{
                                              fontSize: 14,
                                              fontWeight: 800,
                                              color: "#1e1b4b",
                                              margin: 0,
                                            }}
                                          >
                                            Syntax Reference &amp; Golden Rules
                                          </h5>
                                        </div>
                                        <span
                                          style={{
                                            fontSize: 11,
                                            fontWeight: 700,
                                            color: "#6366f1",
                                            background: "#eef2ff",
                                            padding: "2px 8px",
                                            borderRadius: 6,
                                          }}
                                        >
                                          Quick Reference
                                        </span>
                                      </div>

                                      {filteredCheatsheets.map(
                                        (cs: any, cIdx: number) => (
                                          <div
                                            key={cIdx}
                                            style={{
                                              marginBottom:
                                                cIdx <
                                                filteredCheatsheets.length - 1
                                                  ? 16
                                                  : 0,
                                            }}
                                          >
                                            <div
                                              style={{
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "space-between",
                                                marginBottom: 8,
                                              }}
                                            >
                                              <div
                                                style={{
                                                  fontWeight: 700,
                                                  fontSize: 13,
                                                  color: "#334155",
                                                }}
                                              >
                                                {cs.title}
                                              </div>
                                              <button
                                                onClick={() =>
                                                  setActiveDocModal({
                                                    title: cs.title,
                                                    source:
                                                      cs.source ||
                                                      "Quick Reference",
                                                    url: cs.url,
                                                    keyPoints: cs.keyPoints,
                                                    topic: mod.topic,
                                                    readingTime: "2 min read",
                                                  })
                                                }
                                                style={{
                                                  display: "inline-flex",
                                                  alignItems: "center",
                                                  gap: 5,
                                                  background: "#eef2ff",
                                                  color: "#4338ca",
                                                  border: "none",
                                                  borderRadius: 6,
                                                  padding: "4px 10px",
                                                  fontSize: 11,
                                                  fontWeight: 700,
                                                  cursor: "pointer",
                                                }}
                                              >
                                                <BookOpen size={12} /> Read in
                                                System
                                              </button>
                                            </div>
                                            <ul
                                              style={{
                                                margin: 0,
                                                paddingLeft: 20,
                                                display: "flex",
                                                flexDirection: "column",
                                                gap: 6,
                                              }}
                                            >
                                              {cs.keyPoints?.map(
                                                (pt: string, pIdx: number) => (
                                                  <li
                                                    key={pIdx}
                                                    style={{
                                                      fontSize: 13,
                                                      color: "#1e293b",
                                                      lineHeight: 1.5,
                                                    }}
                                                  >
                                                    {pt}
                                                  </li>
                                                ),
                                              )}
                                            </ul>
                                          </div>
                                        ),
                                      )}
                                    </div>
                                  )}
                                </div>
                              );
                            })}

                            {/* Empty State when no resources match the active search/group filter */}
                            {grandTotalMatches === 0 && (
                              <div
                                style={{
                                  background: "#ffffff",
                                  border: "1.5px dashed #cbd5e1",
                                  borderRadius: 14,
                                  padding: "36px 24px",
                                  textAlign: "center",
                                }}
                              >
                                <Search
                                  size={36}
                                  color="#94a3b8"
                                  style={{ margin: "0 auto 12px" }}
                                />
                                <h5
                                  style={{
                                    fontSize: 16,
                                    fontWeight: 700,
                                    color: "#1e293b",
                                    margin: "0 0 6px",
                                  }}
                                >
                                  No learning resources found
                                  {resourceSearchQuery
                                    ? ` matching "${resourceSearchQuery}"`
                                    : " for this category"}
                                </h5>
                                <p
                                  style={{
                                    fontSize: 13,
                                    color: "#64748b",
                                    margin: "0 0 16px",
                                    maxWidth: 420,
                                    marginLeft: "auto",
                                    marginRight: "auto",
                                  }}
                                >
                                  Try clearing your search query, switching to
                                  &quot;All Resources&quot;, or choosing
                                  &quot;All Topics Across Pack&quot;.
                                </p>
                                <button
                                  onClick={() => {
                                    setResourceSearchQuery("");
                                    setResourceTypeFilter("all");
                                    setSearchScope("all");
                                  }}
                                  style={{
                                    background: "#4f46e5",
                                    color: "#ffffff",
                                    border: "none",
                                    borderRadius: 8,
                                    padding: "9px 18px",
                                    fontSize: 12,
                                    fontWeight: 700,
                                    cursor: "pointer",
                                    boxShadow:
                                      "0 2px 8px rgba(79, 70, 229, 0.25)",
                                  }}
                                >
                                  Reset Search &amp; Filters
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  )}
              </div>
            )}
          </div>
        </section>
        )}

        {/* Question-by-Question Response Review */}
        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e6e9ef",
            borderRadius: 16,
            padding: 32,
            boxShadow: "0 4px 20px rgba(0,0,0,0.03)",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 20,
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 800,
                color: "#1d2536",
                margin: 0,
                display: "flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              <FileText size={20} color="#6255e7" /> Question-by-Question
              Response Breakdown
            </h2>
            <span style={{ fontSize: 12, fontWeight: 700, color: "#64748b" }}>
              {questionsList.length} Questions Evaluated
            </span>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {questionsList.length === 0 ? (
              <div
                style={{
                  padding: 24,
                  textAlign: "center",
                  color: "#64748b",
                  fontSize: 13,
                  fontStyle: "italic",
                }}
              >
                Response breakdown details recorded for this attempt.
              </div>
            ) : (
              questionsList.map((q: any, idx: number) => (
                <div
                  key={q.questionId || idx}
                  style={{
                    background: "#f8fafc",
                    border: `1.5px solid ${q.isCorrect ? "rgba(34, 197, 94, 0.4)" : "rgba(239, 68, 68, 0.4)"}`,
                    borderRadius: 12,
                    padding: 20,
                  }}
                >
                  {/* Header line */}
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "flex-start",
                      gap: 16,
                      marginBottom: 10,
                    }}
                  >
                    <div
                      style={{
                        fontWeight: 700,
                        fontSize: 15,
                        color: "#1d2536",
                        flex: 1,
                      }}
                    >
                      Q{idx + 1}. {q.prompt}
                    </div>
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 800,
                        color: q.isCorrect ? "#16a34a" : "#dc2626",
                        background: q.isCorrect ? "#dcfce7" : "#fee2e2",
                        padding: "3px 10px",
                        borderRadius: 6,
                        whiteSpace: "nowrap",
                      }}
                    >
                      {q.earned} / {q.points} Pts
                    </span>
                  </div>

                  {/* Submissions comparison grid */}
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fit, minmax(280px, 1fr))",
                      gap: 12,
                      marginTop: 12,
                    }}
                  >
                    {/* Student Answer */}
                    <div
                      style={{
                        background: q.isCorrect ? "#f0fdf4" : "#fef2f2",
                        border: `1px solid ${q.isCorrect ? "#bbf7d0" : "#fecaca"}`,
                        borderRadius: 8,
                        padding: 12,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 11,
                          fontWeight: 800,
                          color: q.isCorrect ? "#16a34a" : "#dc2626",
                          textTransform: "uppercase",
                          marginBottom: 4,
                        }}
                      >
                        Your Answer Submitted
                      </div>
                      <div
                        style={{
                          fontSize: 13,
                          fontWeight: 600,
                          color: "#1e293b",
                          fontFamily:
                            q.type === "command" || q.type === "coding"
                              ? "monospace"
                              : "inherit",
                        }}
                      >
                        {q.studentAnswer || "No response provided"}
                      </div>
                    </div>

                    {/* Correct Rubric */}
                    <div
                      style={{
                        background: "#ffffff",
                        border: "1px solid #e2e8f0",
                        borderRadius: 8,
                        padding: 12,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 11,
                          fontWeight: 800,
                          color: "#64748b",
                          textTransform: "uppercase",
                          marginBottom: 4,
                        }}
                      >
                        Correct Answer / Expected Rubric
                      </div>
                      <div
                        style={{
                          fontSize: 13,
                          fontWeight: 600,
                          color: "#1e293b",
                          fontFamily:
                            q.type === "command" || q.type === "coding"
                              ? "monospace"
                              : "inherit",
                        }}
                      >
                        {q.correctAnswer || "Correct solution"}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* ══════════════════════════════════════════════════════════════════
            IN-SYSTEM VIDEO PLAYER MODAL ("WATCH IN SYSTEM")
           ══════════════════════════════════════════════════════════════════ */}
        {activeVideoModal && (
          <div
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 9999,
              background: "rgba(10, 15, 30, 0.88)",
              backdropFilter: "blur(8px)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: 16,
            }}
            onClick={(e) => {
              if (e.target === e.currentTarget) setActiveVideoModal(null);
            }}
          >
            <div
              style={{
                width: "100%",
                maxWidth: 920,
                maxHeight: "92vh",
                background: "#0f172a",
                borderRadius: 16,
                border: "1px solid rgba(255, 255, 255, 0.15)",
                overflow: "hidden",
                display: "flex",
                flexDirection: "column",
                boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.7)",
                position: "relative",
              }}
            >
              {/* Modal Header */}
              <div
                style={{
                  padding: "14px 20px",
                  background: "rgba(15, 23, 42, 0.95)",
                  borderBottom: "1px solid rgba(255, 255, 255, 0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 12,
                  flexShrink: 0,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    minWidth: 0,
                  }}
                >
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 8,
                      background: "#e11d48",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <Play size={16} fill="#ffffff" color="#ffffff" />
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 8,
                        flexWrap: "wrap",
                      }}
                    >
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 800,
                          color: "#fecdd3",
                          background: "rgba(225, 29, 72, 0.2)",
                          padding: "2px 8px",
                          borderRadius: 4,
                          textTransform: "uppercase",
                        }}
                      >
                        {activeVideoModal.platform}
                      </span>
                      {activeVideoModal.duration && (
                        <span style={{ fontSize: 11, color: "#94a3b8" }}>
                          ⏱️ {activeVideoModal.duration}
                        </span>
                      )}
                      {activeVideoModal.topic && (
                        <span
                          style={{
                            fontSize: 11,
                            color: "#a5b4fc",
                            background: "rgba(99, 102, 241, 0.15)",
                            padding: "2px 7px",
                            borderRadius: 4,
                          }}
                        >
                          {activeVideoModal.topic}
                        </span>
                      )}
                    </div>
                    <h3
                      style={{
                        fontSize: 14,
                        fontWeight: 700,
                        color: "#ffffff",
                        margin: "4px 0 0",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {activeVideoModal.title}
                    </h3>
                  </div>
                </div>

                <button
                  onClick={() => setActiveVideoModal(null)}
                  style={{
                    background: "rgba(255, 255, 255, 0.1)",
                    border: "none",
                    borderRadius: 8,
                    width: 32,
                    height: 32,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#ffffff",
                    cursor: "pointer",
                    transition: "background 0.15s ease",
                    flexShrink: 0,
                  }}
                  title="Close Modal"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Player Viewport (Responsive Adaptive 16:9 Container) */}
              <div
                style={{
                  position: "relative",
                  width: "100%",
                  flex: "1 1 auto",
                  minHeight: 0,
                  maxHeight: "calc(92vh - 140px)",
                  background: "#000000",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: "100%",
                    maxWidth: "min(100%, calc((92vh - 140px) * (16 / 9)))",
                    aspectRatio: "16 / 9",
                    maxHeight: "calc(92vh - 140px)",
                    position: "relative",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {(() => {
                    const embedUrl = getYouTubeEmbedUrl(activeVideoModal.url);
                    if (embedUrl) {
                      return (
                        <iframe
                          src={embedUrl}
                          title={activeVideoModal.title}
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                          allowFullScreen
                          style={{
                            width: "100%",
                            height: "100%",
                            border: "none",
                          }}
                        />
                      );
                    }
                    return (
                      <div
                        style={{
                          width: "100%",
                          height: "100%",
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: 24,
                          textAlign: "center",
                          background:
                            "linear-gradient(180deg, #0f172a 0%, #1e293b 100%)",
                        }}
                      >
                        <Video
                          size={44}
                          color="#e11d48"
                          style={{ marginBottom: 12 }}
                        />
                        <h4
                          style={{
                            color: "#ffffff",
                            fontSize: 15,
                            margin: "0 0 6px",
                          }}
                        >
                          Courseware Lecture &amp; Visual Reference
                        </h4>
                        <p
                          style={{
                            color: "#94a3b8",
                            fontSize: 12,
                            maxWidth: 480,
                            margin: "0 0 16px",
                            lineHeight: 1.5,
                          }}
                        >
                          This lecture is provided through {activeVideoModal.platform}.
                          Launch the stream below to view the interactive syllabus and
                          lecture recordings directly.
                        </p>
                        <a
                          href={activeVideoModal.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            display: "inline-flex",
                            alignItems: "center",
                            gap: 8,
                            background: "#e11d48",
                            color: "#ffffff",
                            fontWeight: 700,
                            fontSize: 13,
                            padding: "9px 18px",
                            borderRadius: 8,
                            textDecoration: "none",
                            boxShadow: "0 4px 14px rgba(225, 29, 72, 0.4)",
                          }}
                        >
                          <Play size={14} fill="#ffffff" /> Open Lecture on{" "}
                          {activeVideoModal.platform}
                        </a>
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* Companion Study Bar Footer (Permanently Anchored & Always Visible) */}
              <div
                style={{
                  padding: "12px 20px",
                  background: "#0b1120",
                  borderTop: "1px solid rgba(255, 255, 255, 0.1)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  flexWrap: "wrap",
                  gap: 10,
                  flexShrink: 0,
                  zIndex: 10,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    flexWrap: "wrap",
                  }}
                >
                  <button
                    onClick={() => {
                      setWatchedVideos((prev) => ({
                        ...prev,
                        [activeVideoModal.title]: !prev[activeVideoModal.title],
                      }));
                    }}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                      background: watchedVideos[activeVideoModal.title]
                        ? "#10b981"
                        : "rgba(255, 255, 255, 0.12)",
                      color: "#ffffff",
                      border: "none",
                      borderRadius: 8,
                      padding: "8px 14px",
                      fontSize: 12,
                      fontWeight: 700,
                      cursor: "pointer",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <Check size={14} />
                    {watchedVideos[activeVideoModal.title]
                      ? "Completed (Watched)"
                      : "Mark as Watched"}
                  </button>
                  {activeVideoModal.level && (
                    <span style={{ fontSize: 12, color: "#94a3b8" }}>
                      Target Level:{" "}
                      <strong style={{ color: "#e2e8f0" }}>
                        {activeVideoModal.level}
                      </strong>
                    </span>
                  )}
                </div>

                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    flexWrap: "wrap",
                  }}
                >
                  <a
                    href={activeVideoModal.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      fontSize: 12,
                      color: "#94a3b8",
                      textDecoration: "none",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                      padding: "6px 10px",
                      borderRadius: 6,
                      background: "rgba(255, 255, 255, 0.05)",
                    }}
                  >
                    External Source <ExternalLink size={12} />
                  </a>
                  <button
                    onClick={() => setActiveVideoModal(null)}
                    style={{
                      background: "rgba(255, 255, 255, 0.1)",
                      border: "1px solid rgba(255, 255, 255, 0.2)",
                      borderRadius: 6,
                      color: "#ffffff",
                      padding: "6px 14px",
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            IN-SYSTEM DOCUMENT READER MODAL ("READ IN SYSTEM")
           ══════════════════════════════════════════════════════════════════ */}
        {activeDocModal && (() => {
          const article = getComprehensiveArticleContent(activeDocModal);

          return (
            <div
              style={{
                position: "fixed",
                inset: 0,
                zIndex: 9999,
                background: "rgba(15, 23, 42, 0.8)",
                backdropFilter: "blur(6px)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: 16,
              }}
              onClick={(e) => {
                if (e.target === e.currentTarget) setActiveDocModal(null);
              }}
            >
              <div
                style={{
                  width: "100%",
                  maxWidth: 880,
                  height: "92vh",
                  maxHeight: "92vh",
                  background: "#ffffff",
                  borderRadius: 16,
                  boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.35)",
                  display: "flex",
                  flexDirection: "column",
                  overflow: "hidden",
                  border: "1px solid #cbd5e1",
                  position: "relative",
                }}
              >
                {/* Reader Header */}
                <div
                  style={{
                    padding: "14px 22px",
                    background: "#f8fafc",
                    borderBottom: "1px solid #e2e8f0",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 12,
                    flexShrink: 0,
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      minWidth: 0,
                    }}
                  >
                    <div
                      style={{
                        width: 34,
                        height: 34,
                        borderRadius: 8,
                        background: "#eff6ff",
                        border: "1px solid #bfdbfe",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "#2563eb",
                        flexShrink: 0,
                      }}
                    >
                      <BookOpen size={18} />
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                          flexWrap: "wrap",
                        }}
                      >
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 700,
                            color: "#1d4ed8",
                            background: "#dbeafe",
                            padding: "2px 8px",
                            borderRadius: 4,
                          }}
                        >
                          {activeDocModal.source}
                        </span>
                        {activeDocModal.topic && (
                          <span
                            style={{
                              fontSize: 11,
                              fontWeight: 700,
                              color: "#4338ca",
                              background: "#e0e7ff",
                              padding: "2px 8px",
                              borderRadius: 4,
                            }}
                          >
                            {activeDocModal.topic}
                          </span>
                        )}
                        <span style={{ fontSize: 11, color: "#64748b" }}>
                          ⏱️ {activeDocModal.readingTime || "4 min read"}
                        </span>
                      </div>
                      <h3
                        style={{
                          fontSize: 15,
                          fontWeight: 800,
                          color: "#0f172a",
                          margin: "3px 0 0",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                        }}
                      >
                        {activeDocModal.title}
                      </h3>
                    </div>
                  </div>

                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      flexShrink: 0,
                    }}
                  >
                    {/* Font Size Adjusters (active in article mode) */}
                    {readerTab === "article" && (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          background: "#ffffff",
                          border: "1px solid #cbd5e1",
                          borderRadius: 6,
                          overflow: "hidden",
                        }}
                      >
                        <button
                          onClick={() =>
                            setReaderFontSize((s) => Math.max(13, s - 1))
                          }
                          title="Smaller Text"
                          style={{
                            border: "none",
                            background: "none",
                            padding: "4px 8px",
                            fontSize: 11,
                            fontWeight: 700,
                            color: "#475569",
                            cursor: "pointer",
                            borderRight: "1px solid #cbd5e1",
                          }}
                        >
                          A-
                        </button>
                        <button
                          onClick={() =>
                            setReaderFontSize((s) => Math.min(22, s + 1))
                          }
                          title="Larger Text"
                          style={{
                            border: "none",
                            background: "none",
                            padding: "4px 8px",
                            fontSize: 12,
                            fontWeight: 700,
                            color: "#475569",
                            cursor: "pointer",
                          }}
                        >
                          A+
                        </button>
                      </div>
                    )}

                    <button
                      onClick={() => setActiveDocModal(null)}
                      style={{
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        borderRadius: 8,
                        width: 32,
                        height: 32,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "#64748b",
                        cursor: "pointer",
                      }}
                      title="Close Reader"
                    >
                      <X size={18} />
                    </button>
                  </div>
                </div>

                {/* Reader View Mode Switcher (Article vs Live Web Preview) */}
                <div
                  style={{
                    padding: "0 22px",
                    background: "#f1f5f9",
                    borderBottom: "1px solid #e2e8f0",
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    flexShrink: 0,
                  }}
                >
                  <button
                    onClick={() => setReaderTab("article")}
                    style={{
                      padding: "9px 14px",
                      background: "none",
                      border: "none",
                      borderBottom:
                        readerTab === "article"
                          ? "2.5px solid #4f46e5"
                          : "2.5px solid transparent",
                      fontWeight: 700,
                      fontSize: 12,
                      color: readerTab === "article" ? "#4f46e5" : "#64748b",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    <BookOpen size={13} /> Full Study Article
                  </button>
                  <button
                    onClick={() => setReaderTab("webview")}
                    style={{
                      padding: "9px 14px",
                      background: "none",
                      border: "none",
                      borderBottom:
                        readerTab === "webview"
                          ? "2.5px solid #4f46e5"
                          : "2.5px solid transparent",
                      fontWeight: 700,
                      fontSize: 12,
                      color: readerTab === "webview" ? "#4f46e5" : "#64748b",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    <Globe size={13} /> Live Web Preview
                  </button>
                </div>

                {/* Reader Content Body */}
                {readerTab === "article" ? (
                  <div
                    style={{
                      padding: "28px 34px",
                      overflowY: "auto",
                      flex: "1 1 auto",
                      display: "flex",
                      flexDirection: "column",
                      gap: 24,
                      fontSize: readerFontSize,
                      lineHeight: 1.75,
                      color: "#334155",
                    }}
                  >
                    {/* Article Title & Subject Header */}
                    <div
                      style={{
                        borderBottom: "1.5px solid #f1f5f9",
                        paddingBottom: 16,
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                          marginBottom: 4,
                        }}
                      >
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 800,
                            color: "#4f46e5",
                            textTransform: "uppercase",
                            letterSpacing: "0.5px",
                          }}
                        >
                          Curriculum Reference &amp; Study Guide
                        </span>
                        <span style={{ color: "#94a3b8" }}>·</span>
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 600,
                            color: "#64748b",
                          }}
                        >
                          {article.domain}
                        </span>
                      </div>
                      <h2
                        style={{
                          fontSize: 22,
                          fontWeight: 800,
                          color: "#0f172a",
                          margin: "6px 0 0",
                          lineHeight: 1.3,
                        }}
                      >
                        {activeDocModal.title}
                      </h2>
                    </div>

                    {/* Executive Abstract / Foundational Overview */}
                    <div
                      style={{
                        background: "#f0f7ff",
                        borderLeft: "4px solid #3b82f6",
                        borderRadius: "0 10px 10px 0",
                        padding: "16px 20px",
                        color: "#1e3a8a",
                        fontSize: readerFontSize,
                        lineHeight: 1.7,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 12,
                          fontWeight: 800,
                          color: "#2563eb",
                          textTransform: "uppercase",
                          letterSpacing: "0.5px",
                          marginBottom: 6,
                          display: "flex",
                          alignItems: "center",
                          gap: 6,
                        }}
                      >
                        <BookmarkCheck size={15} /> Academic Overview &amp;
                        Core Thesis
                      </div>
                      {article.abstract}
                    </div>

                    {/* In-Depth Deep-Dive Sections */}
                    {article.sections.map((section, sIdx) => (
                      <div
                        key={sIdx}
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: 12,
                        }}
                      >
                        <h4
                          style={{
                            fontSize: 16,
                            fontWeight: 800,
                            color: "#1e1b4b",
                            margin: "8px 0 0",
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                          }}
                        >
                          <span
                            style={{
                              width: 22,
                              height: 22,
                              borderRadius: 6,
                              background: "#e0e7ff",
                              color: "#4338ca",
                              fontSize: 11,
                              display: "inline-flex",
                              alignItems: "center",
                              justifyContent: "center",
                              flexShrink: 0,
                            }}
                          >
                            {sIdx + 1}
                          </span>
                          {section.heading}
                        </h4>

                        {section.paragraphs.map((pText, pIdx) => (
                          <p
                            key={pIdx}
                            style={{
                              margin: 0,
                              color: "#334155",
                              lineHeight: 1.75,
                            }}
                          >
                            {pText}
                          </p>
                        ))}

                        {/* Formatted Code / Query Snippet */}
                        {section.codeSnippet && (
                          <div
                            style={{
                              background: "#0f172a",
                              borderRadius: 10,
                              border: "1px solid #334155",
                              overflow: "hidden",
                              marginTop: 4,
                            }}
                          >
                            <div
                              style={{
                                padding: "8px 14px",
                                background: "#1e293b",
                                borderBottom: "1px solid #334155",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                              }}
                            >
                              <span
                                style={{
                                  fontSize: 11,
                                  fontWeight: 700,
                                  color: "#94a3b8",
                                  fontFamily: "monospace",
                                }}
                              >
                                {section.codeSnippet.title}
                              </span>
                              <button
                                onClick={() => {
                                  if (section.codeSnippet) {
                                    navigator.clipboard.writeText(
                                      section.codeSnippet.code,
                                    );
                                    setCopiedCodeIdx(sIdx);
                                    setTimeout(() => setCopiedCodeIdx(null), 2000);
                                  }
                                }}
                                style={{
                                  background:
                                    copiedCodeIdx === sIdx
                                      ? "#10b981"
                                      : "rgba(255, 255, 255, 0.1)",
                                  border: "none",
                                  borderRadius: 4,
                                  color: "#ffffff",
                                  fontSize: 11,
                                  fontWeight: 600,
                                  padding: "3px 8px",
                                  cursor: "pointer",
                                  display: "inline-flex",
                                  alignItems: "center",
                                  gap: 4,
                                }}
                              >
                                {copiedCodeIdx === sIdx ? (
                                  <>
                                    <Check size={11} /> Copied!
                                  </>
                                ) : (
                                  <>
                                    <Copy size={11} /> Copy Code
                                  </>
                                )}
                              </button>
                            </div>
                            <pre
                              style={{
                                margin: 0,
                                padding: "14px 16px",
                                color: "#e2e8f0",
                                fontSize: 12.5,
                                lineHeight: 1.6,
                                overflowX: "auto",
                                fontFamily:
                                  "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                              }}
                            >
                              <code>{section.codeSnippet.code}</code>
                            </pre>
                          </div>
                        )}

                        {/* Callout Box */}
                        {section.callout && (
                          <div
                            style={{
                              background: "#fef3c7",
                              borderLeft: "4px solid #f59e0b",
                              borderRadius: "0 8px 8px 0",
                              padding: "12px 16px",
                              fontSize: 12.5,
                              color: "#92400e",
                              marginTop: 4,
                            }}
                          >
                            <strong>Key Concept:</strong> {section.callout}
                          </div>
                        )}
                      </div>
                    ))}

                    {/* Critical Assessment Traps & Exam Mistakes */}
                    {article.assessmentTraps.length > 0 && (
                      <div
                        style={{
                          background: "#fffbeb",
                          border: "1px solid #fcd34d",
                          borderRadius: 12,
                          padding: "18px 22px",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                            fontSize: 14,
                            fontWeight: 800,
                            color: "#92400e",
                            marginBottom: 10,
                          }}
                        >
                          <AlertTriangle size={18} color="#d97706" />
                          Common Assessment Traps &amp; Exam Pitfalls
                        </div>
                        <ul
                          style={{
                            margin: 0,
                            paddingLeft: 20,
                            display: "flex",
                            flexDirection: "column",
                            gap: 8,
                            color: "#78350f",
                            fontSize: 13,
                          }}
                        >
                          {article.assessmentTraps.map((trap, tIdx) => (
                            <li key={tIdx} style={{ lineHeight: 1.55 }}>
                              {trap}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Core Principles & Rules Recap */}
                    {article.keyRules.length > 0 && (
                      <div
                        style={{
                          background: "#ffffff",
                          border: "1px solid #c7d2fe",
                          borderRadius: 12,
                          padding: "18px 22px",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                            fontSize: 14,
                            fontWeight: 800,
                            color: "#1e1b4b",
                            marginBottom: 10,
                          }}
                        >
                          <BookmarkCheck size={18} color="#4f46e5" />
                          Core Principles &amp; Memorization Rules
                        </div>
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 8,
                          }}
                        >
                          {article.keyRules.map((rule, rIdx) => (
                            <div
                              key={rIdx}
                              style={{
                                display: "flex",
                                alignItems: "flex-start",
                                gap: 8,
                                fontSize: 13,
                                color: "#1e293b",
                              }}
                            >
                              <span
                                style={{
                                  color: "#10b981",
                                  fontWeight: 800,
                                  marginTop: 1,
                                }}
                              >
                                ✓
                              </span>
                              <span>{rule}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  /* Live Web Preview Mode (Iframe with External Fallback Banner) */
                  <div
                    style={{
                      flex: "1 1 auto",
                      display: "flex",
                      flexDirection: "column",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        padding: "10px 18px",
                        background: "#fffbeb",
                        borderBottom: "1px solid #fef3c7",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        fontSize: 12,
                        color: "#92400e",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 6,
                        }}
                      >
                        <AlertTriangle size={14} color="#d97706" />
                        <span>
                          Some official documentation portals (e.g. PostgreSQL,
                          MDN) enforce browser embedding policies. If the view
                          does not load below, use Open in New Tab.
                        </span>
                      </div>
                      <a
                        href={activeDocModal.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          color: "#4f46e5",
                          fontWeight: 700,
                          textDecoration: "none",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 4,
                          whiteSpace: "nowrap",
                        }}
                      >
                        Open in New Tab <ExternalLink size={12} />
                      </a>
                    </div>
                    <iframe
                      src={activeDocModal.url}
                      title={activeDocModal.title}
                      style={{
                        flex: 1,
                        width: "100%",
                        border: "none",
                        background: "#ffffff",
                      }}
                      sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                    />
                  </div>
                )}

                {/* Reader Footer (Permanently Anchored & Sticky) */}
                <div
                  style={{
                    padding: "12px 24px",
                    background: "#f8fafc",
                    borderTop: "1px solid #e2e8f0",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    flexWrap: "wrap",
                    gap: 12,
                    flexShrink: 0,
                    zIndex: 10,
                  }}
                >
                  <button
                    onClick={() => {
                      setReadDocs((prev) => ({
                        ...prev,
                        [activeDocModal.title]: !prev[activeDocModal.title],
                      }));
                    }}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                      background: readDocs[activeDocModal.title]
                        ? "#10b981"
                        : "#4f46e5",
                      color: "#ffffff",
                      border: "none",
                      borderRadius: 8,
                      padding: "8px 16px",
                      fontSize: 12,
                      fontWeight: 700,
                      cursor: "pointer",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <Check size={14} />
                    {readDocs[activeDocModal.title]
                      ? "Marked as Read"
                      : "Mark as Read & Understood"}
                  </button>

                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                    }}
                  >
                    <a
                      href={activeDocModal.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        fontSize: 12,
                        color: "#4f46e5",
                        fontWeight: 600,
                        textDecoration: "none",
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 4,
                      }}
                    >
                      Open Original Link <ExternalLink size={12} />
                    </a>
                    <button
                      onClick={() => setActiveDocModal(null)}
                      style={{
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        borderRadius: 8,
                        padding: "7px 14px",
                        fontSize: 12,
                        fontWeight: 600,
                        color: "#475569",
                        cursor: "pointer",
                      }}
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </main>
  );
}
