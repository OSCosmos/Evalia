"use client";

import React, { useState, useEffect } from "react";
import {
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  User,
  Award,
  ShieldAlert,
  Sparkles,
  Brain,
  Loader2,
  RefreshCw,
  BookOpen,
  Target,
  Lightbulb,
} from "lucide-react";
import { Modal } from "../ui/Modal";
import { Badge } from "../ui/Badge";

export interface CandidateSubmission {
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  group: string;
  status: "submitted" | "graded" | "in_progress" | "not_started";
  score: number | null;
  passFail: "Pass" | "Fail" | "Pending" | "—";
  duration: string;
  submittedAt: string;
  attempts: number;
  flags: number;
  attemptId?: string;
  answers: {
    questionId: string;
    prompt: string;
    type: string;
    points: number;
    earned: number;
    studentAnswer: string;
    correctAnswer: string;
    isCorrect: boolean;
  }[];
}

interface Props {
  open: boolean;
  onClose: () => void;
  submission: CandidateSubmission | null;
}

export function CandidateSubmissionModal({ open, onClose, submission }: Props) {
  const [activeTab, setActiveTab] = useState<"answers" | "ai" | "revision">(
    "answers",
  );
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Revision Pack State
  const [revisionPack, setRevisionPack] = useState<any>(null);
  const [loadingPack, setLoadingPack] = useState(false);
  const [packError, setPackError] = useState<string | null>(null);

  const targetId = submission?.attemptId || submission?.candidateId;

  // Reset or pre-fetch AI analysis & revision pack when modal opens
  useEffect(() => {
    if (!open || !targetId) {
      setAiAnalysis(null);
      setAiError(null);
      setRevisionPack(null);
      setPackError(null);
      return;
    }

    let isMounted = true;
    const fetchCachedAIAndPack = async () => {
      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;
      try {
        const res = await fetch(
          `http://localhost:5000/api/v1/assignments/attempts/${targetId}/ai-analysis`,
          {
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
          },
        );
        const data = await res.json();
        if (isMounted && data.success && data.data?.analysis) {
          setAiAnalysis(data.data.analysis);
        }
      } catch (e) {
        // Cached AI fetch is optional
      }

      try {
        const packRes = await fetch(
          `http://localhost:5000/api/v1/assignments/attempts/${targetId}/revision-pack`,
          {
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
          },
        );
        const packData = await packRes.json();
        if (isMounted && packData.success && packData.data?.revisionPack) {
          setRevisionPack(packData.data.revisionPack);
        }
      } catch (e) {
        // Cached Revision pack fetch is optional
      }
    };

    fetchCachedAIAndPack();
    return () => {
      isMounted = false;
    };
  }, [open, targetId]);

  const handleGenerateAI = async (regenerate = false) => {
    if (!targetId) return;
    try {
      setLoadingAI(true);
      setAiError(null);
      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;
      const res = await fetch(
        `http://localhost:5000/api/v1/assignments/attempts/${targetId}/ai-analysis`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ regenerate }),
        },
      );
      const data = await res.json();
      if (data.success && data.data?.analysis) {
        setAiAnalysis(data.data.analysis);
      } else {
        throw new Error(data.message || "Failed to generate AI analysis.");
      }
    } catch (err: any) {
      setAiError(err.message || "Unable to generate candidate AI analysis.");
    } finally {
      setLoadingAI(false);
    }
  };

  const handleFetchOrGenerateRevisionPack = async (regenerate = false) => {
    if (!targetId) return;
    try {
      setLoadingPack(true);
      setPackError(null);
      const token =
        typeof window !== "undefined"
          ? localStorage.getItem("evalia_token") ||
            localStorage.getItem("token")
          : null;
      const res = await fetch(
        `http://localhost:5000/api/v1/assignments/attempts/${targetId}/revision-pack`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ regenerate }),
        },
      );
      const data = await res.json();
      if (data.success && data.data?.revisionPack) {
        setRevisionPack(data.data.revisionPack);
      } else {
        throw new Error(data.message || "Unable to retrieve revision pack.");
      }
    } catch (err: any) {
      setPackError(err.message || "Could not retrieve candidate revision pack.");
    } finally {
      setLoadingPack(false);
    }
  };

  if (!submission) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Candidate Submission: ${submission.candidateName}`}
      width={820}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            width: "100%",
          }}
        >
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={() => setActiveTab("answers")}
              style={{
                padding: "7px 14px",
                borderRadius: 7,
                border: "1px solid var(--border)",
                background:
                  activeTab === "answers"
                    ? "var(--bg-elevated)"
                    : "transparent",
                fontWeight: activeTab === "answers" ? 700 : 500,
                fontSize: 12,
                cursor: "pointer",
                color: "var(--text-primary)",
              }}
            >
              Response Breakdown ({submission.answers.length})
            </button>
            <button
              onClick={() => {
                setActiveTab("ai");
                if (!aiAnalysis && !loadingAI) handleGenerateAI(false);
              }}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                padding: "7px 14px",
                borderRadius: 7,
                border: "1px solid rgba(99, 102, 241, 0.3)",
                background:
                  activeTab === "ai"
                    ? "rgba(99, 102, 241, 0.12)"
                    : "transparent",
                fontWeight: activeTab === "ai" ? 700 : 500,
                fontSize: 12,
                cursor: "pointer",
                color: "#6366f1",
              }}
            >
              <Sparkles size={13} /> AI Performance Review{" "}
              {aiAnalysis ? "✓" : ""}
            </button>
            <button
              onClick={() => {
                setActiveTab("revision");
                if (!revisionPack && !loadingPack)
                  handleFetchOrGenerateRevisionPack(false);
              }}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                padding: "7px 14px",
                borderRadius: 7,
                border: "1px solid rgba(79, 70, 229, 0.3)",
                background:
                  activeTab === "revision"
                    ? "rgba(79, 70, 229, 0.12)"
                    : "transparent",
                fontWeight: activeTab === "revision" ? 700 : 500,
                fontSize: 12,
                cursor: "pointer",
                color: "#4f46e5",
              }}
            >
              <BookOpen size={13} /> Revision Pack {revisionPack ? "✓" : ""}
            </button>
          </div>

          <button
            onClick={onClose}
            style={{
              padding: "8px 18px",
              background: "var(--accent)",
              border: "none",
              borderRadius: 8,
              color: "#fff",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Close Review
          </button>
        </div>
      }
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        {/* Candidate Info Strip */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 12,
            background: "var(--bg-elevated)",
            padding: 16,
            borderRadius: 10,
            border: "1px solid var(--border)",
          }}
        >
          <div>
            <div
              style={{
                fontSize: 11,
                color: "var(--text-muted)",
                marginBottom: 2,
              }}
            >
              Candidate
            </div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>
              {submission.candidateName}
            </div>
            <div style={{ fontSize: 11, color: "var(--text-muted)" }}>
              {submission.candidateEmail}
            </div>
          </div>

          <div>
            <div
              style={{
                fontSize: 11,
                color: "var(--text-muted)",
                marginBottom: 2,
              }}
            >
              Status &amp; Score
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              {submission.score !== null ? (
                <span
                  style={{
                    fontWeight: 700,
                    fontSize: 18,
                    color:
                      submission.passFail === "Pass"
                        ? "var(--status-active)"
                        : "var(--status-danger)",
                  }}
                >
                  {submission.score}%
                </span>
              ) : (
                <span style={{ color: "var(--text-muted)" }}>Not Graded</span>
              )}
              <Badge
                variant={
                  submission.passFail === "Pass"
                    ? "active"
                    : submission.passFail === "Fail"
                      ? "danger"
                      : "warning"
                }
              >
                {submission.passFail}
              </Badge>
            </div>
          </div>

          <div>
            <div
              style={{
                fontSize: 11,
                color: "var(--text-muted)",
                marginBottom: 2,
              }}
            >
              Duration &amp; Date
            </div>
            <div style={{ fontSize: 13, fontWeight: 500 }}>
              <Clock size={12} style={{ verticalAlign: "middle" }} />{" "}
              {submission.duration}
            </div>
            <div style={{ fontSize: 11, color: "var(--text-muted)" }}>
              {submission.submittedAt}
            </div>
          </div>

          <div>
            <div
              style={{
                fontSize: 11,
                color: "var(--text-muted)",
                marginBottom: 2,
              }}
            >
              Proctoring Flags
            </div>
            {submission.flags > 0 ? (
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 4,
                  color: "var(--status-danger)",
                  fontWeight: 600,
                  fontSize: 12,
                }}
              >
                <ShieldAlert size={14} /> {submission.flags} Integrity Events
              </span>
            ) : (
              <span
                style={{
                  color: "var(--status-active)",
                  fontSize: 12,
                  fontWeight: 500,
                }}
              >
                ✓ Clean Session
              </span>
            )}
          </div>
        </div>

        {/* Tab 1: AI Performance Review */}
        {activeTab === "ai" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <Brain size={18} color="#6366f1" />
                <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>
                  Candidate AI Performance Insights
                </h3>
              </div>
              {aiAnalysis && (
                <button
                  onClick={() => handleGenerateAI(true)}
                  disabled={loadingAI}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "5px 12px",
                    borderRadius: 6,
                    border: "1px solid var(--border)",
                    background: "var(--bg-surface)",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: "pointer",
                    color: "var(--text-primary)",
                  }}
                >
                  <RefreshCw
                    size={12}
                    className={loadingAI ? "animate-spin" : ""}
                  />{" "}
                  Regenerate
                </button>
              )}
            </div>

            {loadingAI && (
              <div
                style={{
                  textAlign: "center",
                  padding: 36,
                  background: "var(--bg-surface)",
                  borderRadius: 10,
                }}
              >
                <Loader2
                  size={28}
                  className="animate-spin"
                  style={{ color: "#6366f1", margin: "0 auto 12px" }}
                />
                <p
                  style={{
                    fontSize: 13,
                    color: "var(--text-muted)",
                    margin: 0,
                  }}
                >
                  Generating AI analytical report for {submission.candidateName}
                  ...
                </p>
              </div>
            )}

            {aiError && !loadingAI && (
              <div
                style={{
                  padding: 12,
                  background: "#fee2e2",
                  border: "1px solid #fca5a5",
                  borderRadius: 8,
                  fontSize: 12,
                  color: "#991b1b",
                }}
              >
                {aiError}
              </div>
            )}

            {!aiAnalysis && !loadingAI && !aiError && (
              <div
                style={{
                  textAlign: "center",
                  padding: 36,
                  background: "var(--bg-surface)",
                  borderRadius: 10,
                  border: "1px dashed var(--border)",
                }}
              >
                <Brain
                  size={32}
                  style={{ color: "#6366f1", margin: "0 auto 12px" }}
                />
                <h4
                  style={{ fontSize: 15, fontWeight: 700, margin: "0 0 6px" }}
                >
                  No AI Analysis Generated Yet
                </h4>
                <p
                  style={{
                    fontSize: 13,
                    color: "var(--text-muted)",
                    margin: "0 0 16px",
                  }}
                >
                  Analyze this candidate's attempt to reveal concept mastery,
                  strengths, and study recommendations.
                </p>
                <button
                  onClick={() => handleGenerateAI(false)}
                  style={{
                    padding: "8px 18px",
                    background:
                      "linear-gradient(135deg, #4f46e5 0%, #6366f1 100%)",
                    color: "#ffffff",
                    border: "none",
                    borderRadius: 8,
                    fontWeight: 700,
                    fontSize: 13,
                    cursor: "pointer",
                  }}
                >
                  <Sparkles
                    size={14}
                    style={{ verticalAlign: "middle", marginRight: 6 }}
                  />
                  Generate AI Analysis
                </button>
              </div>
            )}

            {aiAnalysis && !loadingAI && (
              <div
                style={{ display: "flex", flexDirection: "column", gap: 14 }}
              >
                {/* Rating & Executive Summary */}
                <div
                  style={{
                    background: "var(--bg-surface)",
                    border: "1px solid var(--border)",
                    borderRadius: 10,
                    padding: 16,
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      marginBottom: 8,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 800,
                        textTransform: "uppercase",
                        color: "#6366f1",
                      }}
                    >
                      Pedagogical Assessment
                    </span>
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 700,
                        background: "rgba(99, 102, 241, 0.12)",
                        color: "#6366f1",
                        padding: "3px 10px",
                        borderRadius: 12,
                      }}
                    >
                      {aiAnalysis.overallRating}
                    </span>
                  </div>
                  <p
                    style={{
                      fontSize: 13,
                      lineHeight: 1.5,
                      color: "var(--text-primary)",
                      margin: 0,
                    }}
                  >
                    {aiAnalysis.executiveSummary}
                  </p>
                </div>

                {/* Concept Mastery */}
                {Array.isArray(aiAnalysis.conceptMastery) && (
                  <div
                    style={{
                      background: "var(--bg-surface)",
                      border: "1px solid var(--border)",
                      borderRadius: 10,
                      padding: 16,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: "var(--text-primary)",
                        marginBottom: 10,
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                      }}
                    >
                      <Target size={14} color="#6366f1" /> Evaluated Concept
                      Mastery
                    </div>
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "1fr 1fr",
                        gap: 10,
                      }}
                    >
                      {aiAnalysis.conceptMastery.map((cm: any, idx: number) => (
                        <div
                          key={idx}
                          style={{
                            background: "var(--bg-elevated)",
                            padding: 10,
                            borderRadius: 8,
                            fontSize: 12,
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              fontWeight: 600,
                              marginBottom: 4,
                            }}
                          >
                            <span>{cm.concept}</span>
                            <span
                              style={{
                                color:
                                  cm.status === "mastered"
                                    ? "#16a34a"
                                    : cm.status === "developing"
                                      ? "#d97706"
                                      : "#dc2626",
                              }}
                            >
                              {cm.masteryPercentage}%
                            </span>
                          </div>
                          <div
                            style={{ fontSize: 11, color: "var(--text-muted)" }}
                          >
                            {cm.explanation}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Strengths & Weaknesses */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 12,
                  }}
                >
                  <div
                    style={{
                      background: "rgba(34, 197, 94, 0.08)",
                      border: "1px solid rgba(34, 197, 94, 0.25)",
                      borderRadius: 10,
                      padding: 14,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: "#16a34a",
                        marginBottom: 8,
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                      }}
                    >
                      <CheckCircle2 size={14} /> Strengths
                    </div>
                    <ul
                      style={{
                        margin: 0,
                        paddingLeft: 18,
                        fontSize: 12,
                        color: "var(--text-primary)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 6,
                      }}
                    >
                      {(aiAnalysis.strengths || []).map(
                        (s: string, idx: number) => (
                          <li key={idx}>{s}</li>
                        ),
                      )}
                    </ul>
                  </div>

                  <div
                    style={{
                      background: "rgba(245, 158, 11, 0.08)",
                      border: "1px solid rgba(245, 158, 11, 0.25)",
                      borderRadius: 10,
                      padding: 14,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: "#d97706",
                        marginBottom: 8,
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                      }}
                    >
                      <Lightbulb size={14} /> Knowledge Gaps
                    </div>
                    <ul
                      style={{
                        margin: 0,
                        paddingLeft: 18,
                        fontSize: 12,
                        color: "var(--text-primary)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 6,
                      }}
                    >
                      {(aiAnalysis.weaknesses || []).map(
                        (w: string, idx: number) => (
                          <li key={idx}>{w}</li>
                        ),
                      )}
                    </ul>
                  </div>
                </div>

                {/* Study Plan */}
                {aiAnalysis.studyPlan && (
                  <div
                    style={{
                      background: "var(--bg-surface)",
                      border: "1px solid var(--border)",
                      borderRadius: 10,
                      padding: 14,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: "var(--text-primary)",
                        marginBottom: 8,
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                      }}
                    >
                      <BookOpen size={14} color="#6366f1" /> Recommended Student
                      Remediation
                    </div>
                    <div
                      style={{
                        fontSize: 12,
                        color: "var(--text-muted)",
                        marginBottom: 8,
                      }}
                    >
                      Recommended Study Time: ~
                      {aiAnalysis.studyPlan.recommendedHours} hours
                    </div>
                    <ul
                      style={{
                        margin: 0,
                        paddingLeft: 18,
                        fontSize: 12,
                        color: "var(--text-primary)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 4,
                      }}
                    >
                      {(aiAnalysis.studyPlan.actionSteps || []).map(
                        (step: string, idx: number) => (
                          <li key={idx}>{step}</li>
                        ),
                      )}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Personalized Revision Pack */}
        {activeTab === "revision" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: 12,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <BookOpen size={18} color="#4f46e5" />
                <div>
                  <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>
                    Candidate Revision Pack
                  </h3>
                  <p
                    style={{
                      fontSize: 12,
                      color: "var(--text-muted)",
                      margin: 0,
                    }}
                  >
                    Curated multi-source remedial curriculum tailored to candidate performance.
                  </p>
                </div>
              </div>

              {revisionPack && (
                <button
                  onClick={() => handleFetchOrGenerateRevisionPack(true)}
                  disabled={loadingPack}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "5px 12px",
                    borderRadius: 6,
                    border: "1px solid var(--border)",
                    background: "var(--bg-surface)",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: "pointer",
                    color: "var(--text-primary)",
                  }}
                >
                  <RefreshCw
                    size={12}
                    className={loadingPack ? "animate-spin" : ""}
                  />
                  Regenerate
                </button>
              )}
            </div>

            {loadingPack && (
              <div
                style={{
                  background: "var(--bg-surface)",
                  border: "1px solid var(--border)",
                  borderRadius: 10,
                  padding: 32,
                  textAlign: "center",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 10,
                }}
              >
                <Loader2
                  size={24}
                  className="animate-spin"
                  style={{ color: "#4f46e5" }}
                />
                <span style={{ fontSize: 13, fontWeight: 600 }}>
                  Retrieving variable educational sources (Wikipedia REST API, MIT OCW, SQLBolt)...
                </span>
              </div>
            )}

            {packError && (
              <div
                style={{
                  background: "var(--status-danger-bg)",
                  color: "var(--status-danger)",
                  border: "1px solid var(--status-danger-border)",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 13,
                }}
              >
                {packError}
              </div>
            )}

            {!loadingPack && !revisionPack && (
              <div
                style={{
                  background: "var(--bg-surface)",
                  border: "1px dashed var(--border)",
                  borderRadius: 10,
                  padding: 32,
                  textAlign: "center",
                }}
              >
                <BookOpen
                  size={32}
                  color="#4f46e5"
                  style={{ margin: "0 auto 12px" }}
                />
                <div
                  style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}
                >
                  No Revision Pack Generated Yet
                </div>
                <p
                  style={{
                    fontSize: 12,
                    color: "var(--text-muted)",
                    maxWidth: 400,
                    margin: "0 auto 16px",
                  }}
                >
                  Generate a tailored study pack incorporating live academic abstracts, video tutorials, and interactive sandboxes.
                </p>
                <button
                  onClick={() => handleFetchOrGenerateRevisionPack(false)}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "8px 16px",
                    borderRadius: 8,
                    border: "none",
                    background: "linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)",
                    color: "#ffffff",
                    fontSize: 12,
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  <Sparkles size={14} /> Generate Candidate Revision Pack
                </button>
              </div>
            )}

            {!loadingPack && revisionPack && (
              <div
                style={{ display: "flex", flexDirection: "column", gap: 14 }}
              >
                {/* Pack Overview Card */}
                <div
                  style={{
                    background: "var(--bg-surface)",
                    border: "1px solid var(--border)",
                    borderRadius: 10,
                    padding: 14,
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: 10,
                  }}
                >
                  <div>
                    <span style={{ fontWeight: 700, fontSize: 13 }}>
                      {revisionPack.packTitle || "Personalized Revision Pack"}
                    </span>
                    <div
                      style={{ fontSize: 11, color: "var(--text-muted)" }}
                    >
                      {revisionPack.totalModules ||
                        revisionPack.modules?.length ||
                        3}{" "}
                      Curriculum Modules · Est. Study Time: ~
                      {revisionPack.recommendedTotalHours || 5} hours
                    </div>
                  </div>
                  <Badge variant="active">Multi-Source Verified</Badge>
                </div>

                {/* Modules List */}
                {(revisionPack.modules || []).map((mod: any, mIdx: number) => {
                  const isNR = mod.performance === "Needs Review";
                  const isMod = mod.performance === "Moderate";
                  const badgeVariant = isNR
                    ? "danger"
                    : isMod
                      ? "warning"
                      : "active";

                  return (
                    <div
                      key={mod.moduleId || mIdx}
                      style={{
                        background: "var(--bg-surface)",
                        border: "1px solid var(--border)",
                        borderRadius: 10,
                        padding: 16,
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          marginBottom: 8,
                        }}
                      >
                        <div
                          style={{
                            fontWeight: 700,
                            fontSize: 14,
                            color: "var(--text-primary)",
                          }}
                        >
                          {mIdx + 1}. {mod.topic}
                        </div>
                        <Badge variant={badgeVariant}>
                          Performance: {mod.performance}
                        </Badge>
                      </div>

                      {mod.focusStrategy && (
                        <p
                          style={{
                            fontSize: 12,
                            color: "var(--text-muted)",
                            margin: "0 0 10px",
                          }}
                        >
                          <strong>Tier:</strong> {mod.focusStrategy.tier} —{" "}
                          {mod.focusStrategy.description}
                        </p>
                      )}

                      {/* Live Academic Extract */}
                      {mod.liveAcademicContext && (
                        <div
                          style={{
                            background: "var(--bg-elevated)",
                            padding: 10,
                            borderRadius: 6,
                            fontSize: 11,
                            marginBottom: 8,
                          }}
                        >
                          <strong>Live Wikipedia Reference:</strong>{" "}
                          {mod.liveAcademicContext.extract}
                        </div>
                      )}

                      {/* Resource Badges */}
                      <div
                        style={{
                          display: "flex",
                          gap: 8,
                          flexWrap: "wrap",
                          fontSize: 11,
                          color: "var(--text-muted)",
                        }}
                      >
                        {Array.isArray(mod.videoTutorials) && (
                          <span>🎥 {mod.videoTutorials.length} Video(s)</span>
                        )}
                        {Array.isArray(mod.interactiveSandboxes) && (
                          <span>
                            💻 {mod.interactiveSandboxes.length} Sandbox(es)
                          </span>
                        )}
                        {Array.isArray(mod.documentationAndArticles) && (
                          <span>
                            📖 {mod.documentationAndArticles.length} Article(s)
                          </span>
                        )}
                        {Array.isArray(mod.selfCheckQuestions) && (
                          <span>
                            ✓ {mod.selfCheckQuestions.length} Practice Drill(s)
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Standard Answer Breakdown */}
        {activeTab === "answers" && (
          <div>
            <h3
              style={{
                fontSize: 14,
                fontWeight: 700,
                marginBottom: 12,
                color: "var(--text-primary)",
              }}
            >
              Question-by-Question Response Breakdown (
              {submission.answers.length} Questions)
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {submission.answers.map((ans, idx) => (
                <div
                  key={ans.questionId}
                  style={{
                    background: "var(--bg-surface)",
                    border: `1px solid ${ans.isCorrect ? "rgba(34, 197, 94, 0.3)" : "rgba(239, 68, 68, 0.3)"}`,
                    borderRadius: 10,
                    padding: 16,
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: 8,
                    }}
                  >
                    <span style={{ fontWeight: 600, fontSize: 13 }}>
                      Q{idx + 1}. {ans.prompt}
                    </span>
                    <span
                      style={{
                        fontWeight: 700,
                        fontSize: 12,
                        color: ans.isCorrect
                          ? "var(--status-active)"
                          : "var(--status-danger)",
                      }}
                    >
                      {ans.earned} / {ans.points} pts
                    </span>
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr",
                      gap: 12,
                      fontSize: 12,
                      marginTop: 8,
                    }}
                  >
                    <div
                      style={{
                        background: ans.isCorrect
                          ? "var(--status-active-bg)"
                          : "var(--status-danger-bg)",
                        padding: 10,
                        borderRadius: 6,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          textTransform: "uppercase",
                          color: ans.isCorrect
                            ? "var(--status-active)"
                            : "var(--status-danger)",
                          marginBottom: 2,
                        }}
                      >
                        Candidate Answer
                      </div>
                      <div style={{ fontWeight: 500 }}>{ans.studentAnswer}</div>
                    </div>

                    <div
                      style={{
                        background: "var(--bg-elevated)",
                        padding: 10,
                        borderRadius: 6,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          textTransform: "uppercase",
                          color: "var(--text-muted)",
                          marginBottom: 2,
                        }}
                      >
                        Correct Answer / Rubric
                      </div>
                      <div style={{ fontWeight: 500 }}>{ans.correctAnswer}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
